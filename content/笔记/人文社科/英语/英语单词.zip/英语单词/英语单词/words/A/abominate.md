---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbɒmɪneɪt/； 美：/əˈbɑːmɪneɪt/
- #词性/vt  憎恶；厌恶；憎恨；极其讨厌
# 例句
- All the teachers abominate cheating in examinations .
	- 所有教师都憎恶考试作弊。
- He thought highly of human virtues , abominated all evils and immoral behaviors .
	- 他赞赏人性的美德，憎恶一切丑恶和不道德行为。
- For my part , I abominate all honorable respectable toils , trials , and tribulations of every kind whatsoever .
	- 拿我来说，一切尊贵的，叫人敬重的劳动、考验和折磨都使我乏味。
# 形态
- #形态/word_third abominates
- #形态/word_ing abominating
- #形态/word_done abominated
- #形态/word_past abominated
