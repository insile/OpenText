---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌæbəˈlɪʃn/； 美：/ˌæbəˈlɪʃn/
- #词性/n  (法律、制度、习俗等的)废除，废止
# 例句
- Islanders have campaigned for the abolition of one of the three tiers of municipal power on the island .
	- 岛上居民发起一场运动，要求废除岛上三级市政管理层中的一级。
- They preach the abolition of established systems but prose nothing to replace them .
	- 他们竭力主张废除固有的制度，但没有提出代替这些制度的任何建议。
- Some people seemed to believe that with the abolition of the emperor , China had become a democratic country and that hence forth everything would take its proper course .
	- 有人以为没有皇帝，中国就算是民主国家，百事大吉，天下太平了。
