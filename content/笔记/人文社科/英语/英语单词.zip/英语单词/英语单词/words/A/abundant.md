---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈbʌndənt/； 美：/əˈbʌndənt/
- #词性/adj  大量的；充裕的；丰盛的
# 例句
- Birds are abundant in the tall vegetation .
	- 高大的植被中有着大量的鸟类。
- The abundant crevasse prove that fracture is the chief form of yielding .
	- 大量的冰隙证明破裂是变形的主要形式。
- We have abundant evidence to prove his guilt .
	- 我们有充分的证据证明他有罪。
