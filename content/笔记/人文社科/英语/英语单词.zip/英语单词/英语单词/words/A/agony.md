---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæɡəni/； 美：/ˈæɡəni/
- #词性/n  (精神或肉体的)极度痛苦；极大的痛苦
# 例句
- You simply cannot conceive of the agony .
	- 你无法明白什么叫做极大的痛苦。
- We were taught that our armies were always invincible and our causes were always just , only to suffer the agony of Vietnam .
	- 我们教育的军队始终是顽强的，目标始终是正确的，仅仅在越南遭受了极大的痛苦。
- Don 't prolong the agony ─ just tell us who won !
	- 别卖关子了——快说谁赢了！
# 形态
- #形态/word_pl agonies
