---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkɒst/； 美：/əˈkɔːst/
- #词性/vt  搭讪；(贸然)上前搭讪；(唐突地)走近谈话
# 例句
- They have been assigned to accost strangers and extract secrets from them .
	- 他们被指派去与生疏人搭讪从并从他们那里套出奥秘。
- If they were resolute to accost her , she laid her finger on the scarlet letter , and passed on .
	- 如果他们执意要和她搭讪，她就用一个手指按住那红宇，侧身而过。
- She was accosted in the street by a complete stranger .
	- 在街上，一个完全陌生的人贸然走到她跟前搭讪。
# 形态
- #形态/word_third accosts
- #形态/word_ing accosting
- #形态/word_done accosted
- #形态/word_past accosted
