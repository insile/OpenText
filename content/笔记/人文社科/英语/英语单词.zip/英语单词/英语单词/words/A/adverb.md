---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/ˈædvɜːb/； 美：/ˈædvɜːrb/
- #词性/n  副词
# 例句
- In both ancient and modern Chinese languages , the adverb " geng " is very often used .
	- 副词“更”在古代汉语和现代汉语中的使用频率很高。
- The sentence opens with an adverb .
	- 这个句子以一个副词开头。
- We add the suffix " ly " to make the adjective " quick " into the adverb " quickly " .
	- 我们在形容词“quick”后加“ly”构成副词“quickly”。
# 形态
- #形态/word_pl adverbs
