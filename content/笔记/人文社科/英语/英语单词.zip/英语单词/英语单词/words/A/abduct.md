---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/æbˈdʌkt/； 美：/æbˈdʌkt/
- #词性/vt  绑架；劫持；诱拐
# 例句
- The news that we see those use network abduct children sometimes filled with apprehension .
	- 我们有时看到那些利用网络诱拐儿童的新闻都心惊肉跳。
- You here to abduct another one of my patients ?
	- 你想来诱拐我其他的病人吗？
- His car was held up and he was abducted by four gunmen
	- 他的车遭遇拦劫，随后他被4名持枪歹徒劫持。
# 形态
- #形态/word_third abducts
- #形态/word_ing abducting
- #形态/word_done abducted
- #形态/word_past abducted
