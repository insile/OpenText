---
tags:
  - 首字母/A
  - 级别/小学
掌握: false
模糊: false
---
# 词义
- 英：/ə/； 美：/ə/
- #词性/art  一；任何一；每一
# 例句
- I think we could all use a drink after that !
	- 我想我们在事情办完之后都得痛快地喝一杯。
- I 'd like to learn a new language .
	- 我想学习一门新的语言。
- She was invited to give a paper on the results of her research .
	- 她应邀发表一篇论文，报告她的研究结果。
