---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkʌmplɪʃt/； 美：/əˈkɑːmplɪʃt/
- #词性/v  完成
- #词性/adj  熟练的；技艺高超的；才华高的
# 例句
- The first part of the plan has been safely accomplished .
	- 计划的第一部分已顺利完成。
- The task was accomplished with comparative ease .
	- 相对而言，任务完成得比较轻松。
- I don 't feel I 've accomplished very much today .
	- 我觉得我今天没干成多少事。
# 形态
- #形态/word_proto accomplish
