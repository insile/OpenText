---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈlɜːt/； 美：/əˈlɜːrt/
- #词性/adj  警惕的；警觉的；戒备的；注意到；意识到
- #词性/vt  使警惕；使警觉；使戒备；向…报警；使认识到；使意识到
- #词性/n  警报；警戒；警惕；戒备
# 例句
- I managed to walk around unchallenged for 10 minutes before an alert nurse spotted me .
	- 我四处走动了10分钟，没有受到查问，之后一位警觉的护士发现了我。
- He had been spotted by an alert neighbour .
	- 一个警觉的邻居发现了他。
- Following the bomb blast , local hospitals have been put on red alert .
	- 炸弹爆炸之后，当地医院一直处于戒备状态。
# 形态
- #形态/word_third alerts
- #形态/word_ing alerting
- #形态/word_done alerted
- #形态/word_pl alerts
- #形态/word_past alerted
