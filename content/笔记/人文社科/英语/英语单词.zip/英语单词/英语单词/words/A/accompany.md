---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkʌmpəni/； 美：/əˈkʌmpəni/
- #词性/vt  伴随；陪同；陪伴；(尤指用钢琴)为…伴奏；与…同时发生
# 例句
- Government monitors will continue to accompany reporters .
	- 政府监督员将继续陪同记者。
- The member that accompany a person should have led effect well .
	- 陪同人员应很好地起到引领的作用。
- All research proposals must be accompanied by a full motivation .
	- 所有研究计划书均须详述研究动机。
# 形态
- #形态/word_third accompanies
- #形态/word_ing accompanying
- #形态/word_done accompanied
- #形态/word_past accompanied
