---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈæləbɑːstə(r)/； 美：/ˈæləbæstər/
- #词性/n  雪花石膏(常用于雕塑和装饰品)
- #词性/adj  雪花石膏制的；雪花石膏一样的
# 例句
- The floor was marble tile , and the columns alabaster .
	- 地板是由大理石铺成的，柱子则是雪花石膏打造而成。
- I was the first time with alabaster
	- 我是第一次用雪花石膏
- She wore a fine chain about her alabaster neck .
	- 她细腻光滑、美丽白皙的脖子上戴着一条精致的链子。
