---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbaʊnd/； 美：/əˈbaʊnd/
- #词性/vi  大量；大量存在；有许多
# 例句
- Mistakes abound on every page .
	- 每页上都有大量错误。
- Opportunities abound both in science and other areas for fine careers .
	- 无论从事科学事业或在其他领域工作，都有取得成就的大量机会。
- Stories about his travels abound .
	- 有关他游历的故事多得很。
# 形态
- #形态/word_third abounds
- #形态/word_ing abounding
- #形态/word_done abounded
- #形态/word_past abounded
