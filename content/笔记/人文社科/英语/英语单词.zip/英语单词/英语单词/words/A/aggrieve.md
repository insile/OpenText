---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/v  使委屈；使悲痛；侵害；冤枉
# 例句
- Transshipment without permission , copy and other behaviors that aggrieve copyright are forbidden .
	- 禁止未经许可转载、复制及其他侵害著作权行为。
- The superposition of neither fact marry and law marry severity aggrieve law marry or consort right .
	- 法律婚与事实婚的重合，法律婚与法律婚的重合，都是对法律婚或者说配偶权的严重侵害，均可构成重婚罪。
- I really feel aggrieved at this sort of thing .
	- 我真为这种事感到委屈。
# 形态
- #形态/word_third aggrieves
- #形态/word_done aggrieved
- #形态/word_ing aggrieving
- #形态/word_past aggrieved
