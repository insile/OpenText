---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əkˈsentʃueɪt/； 美：/əkˈsentʃueɪt/
- #词性/vt  强调；使突出；着重
# 例句
- The author should accentuate his contributions in this manuscript .
	- 作者应着重指出指出本人的贡献。
- There is no place for metaphor or analogy in this process , since these accentuate the superficial .
	- 在此过程中没有隐喻和类推，因为设计着重于表面。
- His shaven head accentuates his large round face
	- 光头使他的大圆脸更加突出。
# 形态
- #形态/word_third accentuates
- #形态/word_ing accentuating
- #形态/word_done accentuated
- #形态/word_past accentuated
