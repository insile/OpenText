---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈælkəmɪst/； 美：/ˈælkəmɪst/
- #词性/n  炼金术士
# 例句
- At first glance , it all seems an alchemist 's illusion .
	- 乍看上去，它完全像是一位炼金术士的幻术。
- Well , I 've always seen myself as an alchemist , a catalyst for change .
	- 好吧，我总认为自己是个炼金术士和变化的催化剂。
- Alchemists found that a number of materials were especially useful in their work .
	- 炼金术士们发现在炼制黄金过程中，有几种原料对他们特别有用。
# 形态
- #形态/word_pl alchemists
