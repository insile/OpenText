---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbleɪz/； 美：/əˈbleɪz/
- #词性/adj  燃烧；闪耀；发光；明亮；色彩鲜艳；充满激情的；情绪激动的；猛烈燃烧
# 例句
- Set these black nights ablaze
	- 在这些黑夜里燃烧起来
- But the minute you switch on the light in your bathroom , the world is ablaze with color and energy .
	- 但是，这时候，你的光开关中的浴室，世界正在燃烧的彩色和能源。
- He turned to her , his eyes ablaze with anger .
	- 他怒目圆睁，转过身来对着她。
