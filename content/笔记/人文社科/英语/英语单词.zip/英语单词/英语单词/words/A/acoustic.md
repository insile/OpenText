---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkuːstɪk/； 美：/əˈkuːstɪk/
- #词性/adj  声学的；声音的；音响的；听觉的；原声的；自然声的
- #词性/n  （空间的）传声效果，音响效果
# 例句
- Abstract Active control is now being vigorously investigated in various acoustic fields .
	- 有源控制已在声学的各个领域内进行着富有成效的研究。
- Since then , the acoustic sound system , the singer began to guide the way forward .
	- 从此，声学的发音体系便开始指导着演唱者的前进方向。
- He plays a solo acoustic set .
	- 他伴着原声乐器独唱了一组歌曲。
