---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əbˈhɒrənt/； 美：/əbˈhɔːrənt/
- #词性/adj  (尤指因道德原因)令人憎恨的，令人厌恶的，令人憎恶的；可憎的
# 例句
- So the water on the left moves up in order to avoid there being the vacuum , its striving to avoid this abhorrent situation of a vacuum .
	- 左边的水上升就是为了避免真空状态的发生，尽量避免那种令人厌恶的情形。
- Not for any mortal sin , but the wickedness of my abhorrent face !
	- 不是因为弥天大罪，而是因了这令人憎恶的脸代表的邪恶！
- Racism is abhorrent to a civilized society .
	- 文明社会憎恶种族主义。
