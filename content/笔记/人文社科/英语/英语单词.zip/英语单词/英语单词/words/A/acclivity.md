---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/n  （向上的）斜坡；上斜
# 例句
- As soon as we down the slope of sadness , we accelerate over the ever-feel-good acclivity of happiness .
	- 每当我们陷入忧愁的低谷时，我们以开始冲向开心的谷顶。
- As soon as we descend down the slope of sadness , we accelerate over the ever-feel-good acclivity of happiness .
	- 一旦我们从痛苦的斜坡滑下去，我们就加速开始有快乐的感觉。
- It prompted the matron to say that she would walk a little way - as far as to the point where the acclivity from the valley began its first steep ascent to the outer world .
	- 因此这位家庭主妇说，她要送姑娘一程要把姑娘送到山谷斜坡上的那个地点，那个斜坡是通向外部世界的第一个制高点。
# 形态
- #形态/word_pl acclivities
