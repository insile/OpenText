---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/ədˈvɑːntɪdʒ/； 美：/ədˈvæntɪdʒ/
- #词性/n  优势；优点；有利条件；有利因素；(局末平分后)占先；优势分
- #词性/vt  有利于；有助于；使处于有利地位
# 例句
- She had the advantage of a good education .
	- 她具有受过良好教育的有利条件。
- But with more than two million grey squirrels in the UK and just 150000 native reds , they could do with any advantage that evolution has given them .
	- 但英国有200多万只灰松鼠，而仅有15万只土生土长的红松鼠，红松鼠需要利用进化赋予它们的任何有利条件。
- Eventually , the new regulations will work to our advantage .
	- 新规章制度最终将对我们有利。
# 形态
- #形态/word_third advantages
- #形态/word_ing advantaging
- #形态/word_done advantaged
- #形态/word_pl advantages
- #形态/word_past advantaged
