---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈdɔː(r)/； 美：/əˈdɔːr/
- #词性/vt  崇拜；热爱，爱慕(某人)；喜爱，热爱(某事物)
# 例句
- Ever since I have known you I adore you more every day .
	- 自我与你相识，我一天比一天更崇拜你。
- Much as I adore your company , may I tear myself away ?
	- 虽然我很崇拜你的连队，但我可以先离开吗？
- She adores working with children .
	- 她热爱为儿童工作。
# 形态
- #形态/word_third adores
- #形态/word_ing adoring
- #形态/word_done adored
- #形态/word_past adored
