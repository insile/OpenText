---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪliəs/； 美：/ˈeɪliəs/
- #词性/n  别名；(尤指罪犯所用的)化名；(文件、互联网地址等用的)假名
- #词性/adv  (罪犯或演员等)又名；化名；亦名
# 例句
- You can replace this automatically generated alias with a more meaningful one .
	- 可用更有意义的名称替换这一自动生成的别名。
- Finally , this paper presents the security check based on the alias analysis .
	- 最后，本文论述了基于别名分析能够完成的部分安全检查。
- Using an alias , he had rented a house in Fleet , Hampshire .
	- 他用化名在汉普郡的舰队街租了间房子。
# 形态
- #形态/word_pl aliases
