---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/'ædjʊleɪt/； 美：/'ædʒəˌleɪt/
- #词性/v  奉承；谄媚；成年之后才谄媚；极度谄媚
# 例句
- What is there to adulate in her .
	- 她有什么值得吹捧的！
