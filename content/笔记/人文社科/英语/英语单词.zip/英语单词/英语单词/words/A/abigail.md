---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性缺失 阿比盖尔；艾比盖尔；亚比该；艾碧
# 例句
- Abigail 's mother Linda views her daughter 's talent with a mixture of pride and worry
	- 阿比盖尔的母亲琳达带着一种又骄傲又担忧的复杂情绪看待女儿的才华。
- Perhaps it 's time Abigail is released from clinical treatment .
	- 也许是时候把阿比盖尔从治疗当中释放出来了。
- His estranged5 daughter ( Abigail Breslin ) is studying in Marseille when she is arrested and charged with the murder of her girlfriend .
	- 和他关系疏远的女儿（阿比盖尔·布雷斯林饰演）在法国马赛读书期间突然被捕并被控谋杀女友。
