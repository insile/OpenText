---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ədˈmɒnɪʃ/； 美：/ədˈmɑːnɪʃ/
- #词性/v  告诫；警告；责备；忠告；力劝
# 例句
- Let Channa say whatever he may like , Ananda , the brethren should neither speak to him , nor exhort him , nor admonish him .
	- 让Channa说他也喜欢说的，阿难，兄弟们不会对他说，不会劝告他，或责备他。
- The new approach is designed to admonish motorists without hitting them in the wallet .
	- 这种新措施旨在告诫车主，但同时不收罚金。
- A warning voice admonished him not to let this happen .
	- 他耳边响起警钟，警告他别让这种事情发生。
# 形态
- #形态/word_third admonishes
- #形态/word_ing admonishing
- #形态/word_done admonished
- #形态/word_past admonished
