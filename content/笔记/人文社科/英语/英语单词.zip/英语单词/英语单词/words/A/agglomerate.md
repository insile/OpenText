---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈɡlɒməreɪt , əˈɡlɒmərət/； 美：/əˈɡlɑːməreɪt , əˈɡlɑːmərət/
- #词性/v  结块；(使)成团，聚结
- #词性/n  大团；聚结物
- #词性/adj  聚结的；成团的
# 例句
- The sealing length of the ash-cabins has been prolonged in order to avoid ash agglomerate .
	- 通过延长灰仓的密封长度，防止了灰粉结块。
- In general , fine particles tend to clump and agglomerate if they are moist or tacky .
	- 通常潮湿和粘性的微细颗粒易于聚集和结块。
- They agglomerated many small pieces of research into a single large study .
	- 他们把许多小的研究课题汇集成一个大项目。
# 形态
- #形态/word_third agglomerates
- #形态/word_ing agglomerating
- #形态/word_done agglomerated
- #形态/word_past agglomerated
