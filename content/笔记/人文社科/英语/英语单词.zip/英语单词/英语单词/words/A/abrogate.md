---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈæbrəɡeɪt/； 美：/ˈæbrəɡeɪt/
- #词性/vt  废除，废止，撤销(法律、协议等)
# 例句
- The next prime minister could abrogate the treaty .
	- 下一任首相可能会废除这个条约。
- Abrogate a law , custom , treaty .
	- 废除一法例、习俗、条约。
- This law has been abrogated .
	- 这项法令今已取消。
# 形态
- #形态/word_third abrogates
- #形态/word_ing abrogating
- #形态/word_done abrogated
- #形态/word_past abrogated
