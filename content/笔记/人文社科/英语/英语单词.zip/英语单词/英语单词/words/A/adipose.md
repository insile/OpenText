---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædɪpəʊs/； 美：/ˈædɪpoʊs/
- #词性/adj  用于贮存脂肪的
- #词性/n  动物脂肪
# 例句
- After I become pouch operation adipose meeting second birth ?
	- 我做眼袋手术后脂肪会再生吗？
- Adipose tissue as seen in a regular histological section .
	- 组织切片可见脂肪组织。
- PM2.5 exaggerates diet-induced insulin resistance , adipose inflammation , and visceral adiposity .
	- 细微大气颗粒物PM2.5）能增加饮食引起的胰岛素抵抗、脂肪炎症反应、内脏肥胖
