---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈdɒpt/； 美：/əˈdɑːpt/
- #词性/v  采用(某方法)；采取(某态度)；收养；领养；选用（名字等）；选定，选举；正式通过，表决采纳(建议、政策等)
# 例句
- The only way to come out on top is to adopt a different approach .
	- 脱颖而出的唯一途径就是采用一种不同的方法。
- They should adopt a more imaginative approach and investigate alternative uses for their property .
	- 他们应该采用一种更有想象力的方式来为他们的财产找到另外的用途。
- All three teams adopted different approaches to the problem .
	- 三个队处理这个问题的方法各不相同。
# 形态
- #形态/word_third adopts
- #形态/word_ing adopting
- #形态/word_done adopted
- #形态/word_past adopted
