---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/ədˈvɜːtɪsmənt/； 美：/ˌædvərˈtaɪzmənt/
- #词性/n  广告；广告宣传；广告活动；启事；广告(样)品
# 例句
- This will make great copy for the advertisement .
	- 这可当作这则广告的绝妙广告词。
- If I had seen the advertisement in time I would have applied for the job .
	- 我要是及时看到了这则广告，我就应聘那份工作了。
- The advertisements are intended to improve the company 's image .
	- 这些广告旨在提高公司的形象。
# 形态
- #形态/word_pl advertisements
