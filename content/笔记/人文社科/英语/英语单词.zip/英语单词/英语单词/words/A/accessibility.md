---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əkˌsɛsɪˈbɪlɪti/； 美：/ˌæksɛsəˈbɪlɪti/
- #词性/n  可访问性；可达（及）性，可（易）接近性；（新仪表使用前的）检查（查看，操作）步骤（方法）
# 例句
- Heilongjiang Province Water Quality Target Accessibility Analysis for Water Function Zone
	- 黑龙江省水功能区水质目标可达性分析
- Research on the Accessibility Theory of Dynamic Fuzzy Objective
	- 动态模糊（DF）目标的可达性理论研究
- Complies with industry standards for data security , browser compatibility , and accessibility .
	- 遵守并执行有关数据安全、浏览器兼容性，以及残疾人使用方便等方面的工业标准。
