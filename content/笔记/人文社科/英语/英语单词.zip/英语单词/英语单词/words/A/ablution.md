---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbluːʃ(ə)n/； 美：/əb'lʊʃən/
- #词性/n  洗礼；(对人手、人体、圣器等的)沐浴仪式；净器(仪式)
# 例句
- Through stormy ablution , internet industry of China or more will mature .
	- 经过暴风雨的洗礼，中国的互联网行业或将更加成熟。
- It acts like performing ablution to a plain dramatic tale and making it to be solemn , mysterious and meaningful .
	- 它能为一个普通的戏剧故事洗礼，使之变得更为隆重、神秘、含义深刻。
- She will go to school after having ablution .
	- 她沐浴后将去学校。
