---
tags:
  - 首字母/A
  - 级别/雅思
掌握: false
模糊: false
---
# 词义
- #词性/n  曝气；充（通，换，透，进，吹，掺，曝）气；通（鼓，吹，透）风；分解；松砂（散）
# 例句
- Two methods of aeration system design and their results are compared .
	- 对堆肥系统的两种不同风机选型方法及计算结果进行了比较。
- Application of the technology of lifting water and aeration for improving water quality
	- 扬水曝气技术在水源水质改善中的应用
- Study on a New Aeration Device in Bioartificial Liver Support System
	- 生物型人工肝支持系统新型曝气装置的研究
