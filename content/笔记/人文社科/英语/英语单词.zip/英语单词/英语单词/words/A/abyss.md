---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbɪs/； 美：/əˈbɪs/
- #词性/n  深渊
# 例句
- Ahead of them was a gaping abyss .
	- 他们前面是一个巨大的深渊。
- My mother 's criticism had shown me that Kafka is right about the cold abyss , and when you make the introspectivedescent that writing requires you are not always pleased by what you find .
	- 母亲的批评告诉我，卡夫卡对“冰冷的深渊”的看法是正确的，当你进行写作所要求的内省式的沉降时，你并不总是对你所发现的东西感到满意。
- The country is stepping back from the edge of an abyss .
	- 该国临渊而退。
# 形态
- #形态/word_pl abysses
