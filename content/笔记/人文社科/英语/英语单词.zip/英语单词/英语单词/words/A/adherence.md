---
tags:
  - 首字母/A
  - 级别/六级
掌握: false
模糊: false
---
# 词义
- 英：/ədˈhɪərəns/； 美：/ədˈhɪrəns/
- #词性/n  坚持；遵守；遵循
# 例句
- His rigid adherence to old-fashioned ideas made him unpopular .
	- 他顽固坚持旧观念使得他不受欢迎。
- Transformation of the Mode of Thinking and Adherence to Being Objective
	- 思维方式变革与坚持实事求是
- Their religious adherence is not to the established church .
	- 他们信仰的不是国教。
