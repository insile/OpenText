---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/adv #词性/adj  光明正大的；公开（正）的（地）；开诚布公（地）；直率的（地）
# 例句
- He assured us that the deal was all open and aboveboard .
	- 他向我们保证，交易是公开的、光明正大的。
- You 've really been commended on your aboveboard tactics .
	- 你猜用的确还是光明正大的手段。
- A person who is aboveboard does nothing underhand .
	- 明人不做暗事。
