---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈbaɪdɪŋ/； 美：/əˈbaɪdɪŋ/
- #词性/adj  持久的；长久的；始终不渝的
- #词性/v  居住；停留；(十分厌恶而)不能容忍，无法容忍；居留；逗留
# 例句
- He has a genuine and abiding love of the craft
	- 他对这门手艺有着真挚持久的热爱。
- If manager and his organization want to live , develop and succeed in such condition , he should establish abiding advantage in competition , learn excellence management ideal , hold forward management technology and implement effective management methods .
	- 置身于这样一个时代，管理者个人及其组织要想生存、发展，进而求得事业的成功，必须建立持久的竞争优势，学习优秀的管理思想，掌握先进的管理技能，实施有效的管理方法。
- May joy and peace abide in us all .
	- 愿我们大家都欢乐平安。
# 形态
- #形态/word_proto abide
