---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈældʒiː/； 美：/ˈældʒiː/
- #词性/n  藻类；海藻；藻
# 例句
- Supporters of the iron-fertilization theory believe this dust produced blooms of oceanic algae that then sank to the seabed , taking large amounts of carbon with them , which helped to reduce temperatures still further .
	- 支持铁物质增殖作用理论的人认为这些尘埃促成了海洋藻类的茂密生长，后来这些藻类沉入海床，带走了大量的二氧化碳，这进一步降低了地球温度。
- Some experts believe printers could use hydrocolloids from plentiful renewables like algae and grass to replace the familiar ingredients ．
	- 一些专家认为,打印机可以利用大量可再生能源，如藻类和草中的水胶体，来代替熟悉的成分。
- The most effective new botanicals are extracts from cola nut and marine algae .
	- 这种极其有效的新型植物制剂是从可乐果和海藻中提炼出来的。
# 形态
- #形态/word_proto alga
