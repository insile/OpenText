---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/n  恐高症
# 例句
- The Case Report of Mental Consultation about the Second Year Students ' Acrophobia
	- 1名大二学生恐高症心理咨询个案报告
- Having heart disease , hypertension or acrophobia or feeling bad .
	- 患心脏病、高血压、恐高症者，身体感觉不适者。
- Why he is free from acrophobia when standing on a high place ?
	- 站在很高的地方也不会得惧高症？
