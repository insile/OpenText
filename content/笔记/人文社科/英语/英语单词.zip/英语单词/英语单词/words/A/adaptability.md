---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˌdæptəˈbɪlɪti/； 美：/əˌdæptəˈbɪləti/
- #词性/n  适应性；适应（合，用）性；可用性；灵活性；适应能力
# 例句
- The gene-base for adaptability must be increased .
	- 适应性的基因基性必然会有所增加。
- Featuring outstanding flight range , endurance , carrying capacity and environmental adaptability , the Wing Loong-2H UAV is able to conduct field surveys , support emergency communication and deliver emergency supplies in extreme conditions , such as power and network outages and circuit breaks .
	- 该无人机系统具有航程远、留空时间长、承载能力大、环境适应性强等特点，可在“断路、断电、断网”等极端灾害条件下，完成现场探查、公\/专网应急组网通信、应急物资投送等任务。
- A Study on Structure Adaptability of Solvent and Organic Reaction Mechanism
	- 有机反应机理与溶剂的结构适应性
