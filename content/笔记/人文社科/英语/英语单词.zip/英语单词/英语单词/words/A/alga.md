---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性/n  藻类；藻（类）；水藻；海藻
# 例句
- Study on Instrument for Measuring Concentration of Alga Applying Optical Fiber
	- 光纤荧光海藻浓度测量仪的研究
- Study on control of alga and microcystins in source water
	- 水源水中藻类及藻毒素控制试验研究
- Hybrid Alga Identify Method Research Based on Fluorescence and Analysis of Multi-Element Regression Analysis
	- 基于荧光法和多元回归分析的混合海藻识别方法研究
# 形态
- #形态/word_pl algas
