---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/'æfrɪkə/； 美：/ˈæfrəkə/
- #词性/n  非洲
# 例句
- Living in Africa was very different from home and quite an experience .
	- 生活在非洲完全不同于在家里，那真是一次不同寻常的经历。
- Many years later I returned to Africa but that 's another story .
	- 多年以后我又重返非洲，不过这是后话了。
- South America and Africa separated 200 million years ago .
	- 南美洲和非洲于2亿年前分离。
