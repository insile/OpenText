---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkʌmplɪs/； 美：/əˈkɑːmplɪs/
- #词性/n  共犯；帮凶；同谋
# 例句
- Part two discusses the type of the essential accomplice .
	- 第三部分探讨了必要共犯的刑法适用问题。
- Firstly , it give the brief study about the accomplice .
	- 首先，对共犯的概念作简要概述。
- He became an unwitting accomplice in the crime .
	- 他糊里糊涂地成了犯罪的帮凶。
# 形态
- #形态/word_pl accomplices
