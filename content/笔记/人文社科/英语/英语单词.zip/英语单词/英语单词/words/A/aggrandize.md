---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈgrændaɪz/； 美：/əˈgrænˌdaɪz/
- #词性/v  夸大；吹捧(财富、权力或地位)；使(建筑)更宏伟
# 例句
- However , there is a degree of fuzziness . People should not aggrandize it .
	- 然而，模糊是有一个度的，人们不能夸大它。
- Indeed , it should be pointed out that although women status were greatly improved , we can not aggrandize the improvement .
	- 当然，应该指出的是，妇女的地位尽管在罗马后期有了很大的提高，但我们不能夸大这种提高。
- They even manifest enough confidence in themselves and their vastly aggrandized support systems .
	- 他们甚至对于自己已经大大增强了的后勤系统表现了足够的信心。
# 形态
- #形态/word_third aggrandizes
- #形态/word_ing aggrandizing
- #形态/word_done aggrandized
- #形态/word_past aggrandized
