---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˌædəˈlesns/； 美：/ˌædəˈlesns/
- #词性/n  青春期；青春
# 例句
- No one knows for sure why adolescence is unique to humans
	- 没有人确切地知道为什么只有人类才会经历青春期。
- As an account of adolescence it could hardly be bettered .
	- 作为描写青春期的书，它已几臻完美。
- Some people become very self-conscious in adolescence .
	- 有些人在青春期会变得异常害羞。
