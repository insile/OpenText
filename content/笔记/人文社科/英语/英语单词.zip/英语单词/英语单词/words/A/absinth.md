---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/n  苦艾酒；苦艾，洋艾；苦艾酒，洋艾酒
# 例句
- Absinth is to be replaced with caramel syrup again .
	- 苦艾可以用焦糖糖浆来取代。
- Layer in order : Chartreuse on bottom then Kirsch and finally Absinth on top .
	- 分层；沙特勒滋在底部，然后是酸樱桃，顶部是茴香酒。
