---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/ˈædʌlt/； 美：/əˈdʌlt/
- #词性/n  成人；(法律上指能为自己的行为负责的)成年人；成年动物
- #词性/adj  (智力、思想、行为)成熟的，成人的；成年的；发育成熟的；仅限成人的(因有色情或暴力内容)
# 例句
- Children must use an approved child restraint or adult seat belt .
	- 儿童必须使用经过认可的儿童安全带或成人座椅安全带。
- It is no longer desirable for adult children to live with their parents .
	- 孩子长大成人后便不再想与父母住在一起了。
- The new law makes no distinction between adults and children .
	- 这项新法律对成人和孩子同等对待。
# 形态
- #形态/word_pl adults
