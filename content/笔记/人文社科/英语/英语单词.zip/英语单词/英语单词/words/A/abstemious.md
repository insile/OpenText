---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əbˈstiːmiəs/； 美：/əbˈstiːmiəs/
- #词性/adj  有节制的；节俭的；饮食有度的
# 例句
- Abstemious meals ; a light eater ; a light smoker ; ate a light supper .
	- 节俭的晚餐；适度的吃；节制的吸烟者；吃了一顿节俭的晚餐。
- They are abstemious and abstain from most of the modern things that other English people , who are now rarely abstentious , enjoy .
	- 他们生活节俭，有意避开其他英国人所享用的大部分现代产品。现代生活节俭的英国人实属罕见。
- He is abstemious in eating and drinking .
	- 他在饮食方面是很有节制的。
