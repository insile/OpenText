---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ədˈhɪə(r)/； 美：/ədˈhɪr/
- #词性/vi  遵守；附着；黏附
# 例句
- All members of the association adhere to a strict code of practice
	- 协会的所有成员都遵守一套严格的行为规范。
- Sikhs were expected to adhere strictly to the religious rules concerning appearance
	- 锡克教徒应当严格遵守该教对外表的规定。
- She adheres to teaching methods she learned over 30 years ago .
	- 她依循她30多年前所学的教学法教学。
# 形态
- #形态/word_third adheres
- #形态/word_ing adhering
- #形态/word_done adhered
- #形态/word_past adhered
