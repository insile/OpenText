---
tags:
  - 首字母/A
  - 级别/雅思
掌握: false
模糊: false
---
# 词义
- 英：/əˌkredɪˈteɪʃn/； 美：/əˌkredɪˈteɪʃn/
- #词性/n  达到标准；证明合格
# 例句
- One accrediting agency is the Council for Higher Education Accreditation .
	- 有一个资信鉴定机构是为了高等教育的
- One accrediting agency is Council for Higher Education Accreditation .
	- 高等教育授权委员会就是这样一个授权机构
- This paper gives an overview of the Verification , Validation and Accreditation ( VV & A ) in High Level Architecture ( HLA ) .
	- 对基于高层体系结构（HighLevelArchitecture，简称HLA）的仿真系统的校核、验证与确认（Verification，ValidationandAccreditation，简称VV&A）问题进行了详细的介绍及分析
