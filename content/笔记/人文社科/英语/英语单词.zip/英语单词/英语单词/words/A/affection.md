---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈfekʃn/； 美：/əˈfekʃn/
- #词性/n  感情；爱情；喜爱；钟爱
# 例句
- The dog has transferred its affection to its new master .
	- 那狗已把它的感情转移到新主人身上。
- He has a deep affection for his old friend .
	- 他对老朋友感情很深。
- I have a great affection for New York .
	- 我很喜欢纽约。
# 形态
- #形态/word_pl affections
