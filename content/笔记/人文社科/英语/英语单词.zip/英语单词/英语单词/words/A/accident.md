---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/ˈæksɪdənt/； 美：/ˈæksɪdənt/
- #词性/n  (交通)事故；意外；偶然的事；不测事件；意外遭遇
# 例句
- I read about the accident in the local paper .
	- 我在当地的报纸上看到了这次事故。
- The traffic took a long time to clear after the accident .
	- 事故过去后很长时间交通才恢复畅通。
- Take out accident insurance before you go on your trip .
	- 去旅行前要办理好意外保险。
# 形态
- #形态/word_pl accidents
