---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ədˈvɑːns/； 美：/ədˈvæns/
- #词性/n  进展；（价格、价值的）上涨，提高；(尤指武装部队的)前进，行进；进步；预付款；勾引
- #词性/v  (知识、技术等)发展，进步；提前；(为了进攻、威胁等)前进，行进；提出；促进；推动；预付；上涨；向前推（至下一步）
- #词性/adj  预先的；事先的；先遣队；先头部队
# 例句
- The general gave the order to advance .
	- 将军下令前进。
- The defences are intended to obstruct any advance by tanks and other vehicles .
	- 这些防御工事用于阻止坦克等车辆前进。
- There were only three of us on the advanced course .
	- 只有我们三人学高级课程。
# 形态
- #形态/word_third advances
- #形态/word_ing advancing
- #形态/word_done advanced
- #形态/word_pl advances
- #形态/word_past advanced
