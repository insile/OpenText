---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædvəsəri/； 美：/ˈædvərseri/
- #词性/n  对手；(辩论、战斗中的)敌手
- #词性/adj  敌手的；敌对的
# 例句
- His rivals knew that they could expect no quarter from such a ruthless adversary .
	- 他的竞争者明白，不能期望如此残忍的对手发善心。
- Elliott crossed the finish line just half a second behind his adversary
	- 埃利奥特跨过终点线时仅比对手落后半秒钟。
- His political adversaries were creating a certain amount of trouble for him .
	- 他的政敌正在给他制造一些麻烦。
# 形态
- #形态/word_pl adversaries
