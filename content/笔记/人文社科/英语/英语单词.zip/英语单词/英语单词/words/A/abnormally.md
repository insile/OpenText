---
tags:
  - 首字母/A
  - 级别/六级
掌握: false
模糊: false
---
# 词义
- 英：/æbˈnɔːməli/； 美：/æbˈnɔrməli/
- #词性/adv  异常；例外；变态地
# 例句
- Abnormally low or high body temperature effect a variety of physiologic responses including lowered metabolic rate .
	- 不正常的低或高体温会影响动物体各种不同的生理应答，包括低代谢率。
- El Ninos are associated with abnormally dry conditions in Southeast Asia and Australia .
	- 厄尔尼诺现象与东南亚和澳大利亚异常干燥的气候条件有关。
- El Nino , Spanish for " the child " , occurs when surface ocean waters in the southern Pacific become abnormally warm .
	- 厄尔尼诺现象,在西班牙语中意为"圣婴",发生在南太平洋表层海水变得异常温暖的时候。
