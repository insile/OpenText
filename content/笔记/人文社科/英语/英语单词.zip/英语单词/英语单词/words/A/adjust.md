---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈdʒʌst/； 美：/əˈdʒʌst/
- #词性/v  调整；调节；适应；习惯；整理
# 例句
- Watch out for sharp bends and adjust your speed accordingly .
	- 当心急转弯并相应调整车速。
- Adjust the aerial 's position and direction for the best reception .
	- 调整天线的位置和方向以达到最佳接收效果。
- It took her a while to adjust to living alone .
	- 她过了一段时间才适应独自生活。
# 形态
- #形态/word_third adjusts
- #形态/word_ing adjusting
- #形态/word_done adjusted
- #形态/word_past adjusted
