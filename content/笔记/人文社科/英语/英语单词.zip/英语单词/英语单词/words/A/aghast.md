---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈɡɑːst/； 美：/əˈɡæst/
- #词性/adj  惊恐；惊骇
# 例句
- Erica looked at him aghast .
	- 埃丽卡惊恐地望着他。
- I was quite aghast when I read some of the questions .
	- 当读到一些问题时，我相当惊恐。
- He stood aghast at the sight of so much blood .
	- 他看见这么多血，吓得目瞪口呆。
