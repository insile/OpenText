---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈeəreɪt/； 美：/ˈereɪt/
- #词性/vt  充气；使(土壤、水等)透气；充二氧化碳于(液体)
# 例句
- We aerate the soil allowing oxygen to be present in small amounts through our anthills .
	- 我们给土壤充气，允许氧气通过我们的蚁丘而少量充满在土壤中。
- In aerated flow solids are fluidized or suspended by the gas .
	- 在充气流动中，固体颗粒被气体流化或悬浮起来。
- Earthworms do the important job of aerating the soil .
	- 蚯蚓做了使土壤透气的重要工作。
# 形态
- #形态/word_third aerates
- #形态/word_ing aerating
- #形态/word_done aerated
- #形态/word_past aerated
