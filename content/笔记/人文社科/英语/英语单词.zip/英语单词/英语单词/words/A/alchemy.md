---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈælkəmi/； 美：/ˈælkəmi/
- #词性/n  (改变事物的)神秘力量，魔力；炼金术(见于中世纪，企图把普通金属炼成黄金)
# 例句
- Richard told me of three 16th-century folio volumes on alchemy .
	- 理查德告诉过我16世纪的三卷关于炼金术的对开本书籍的事。
- Religion had an intimate association with alchemy during the Middle Ages .
	- 在中世纪，宗教和炼金术密切相联。
- Let us imagine that by some political alchemy it had been possible to make all men equal .
	- 让我们想象通过某种政治魔力能使人人平等。
# 形态
- #形态/word_pl alchemies
