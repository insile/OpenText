---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈeəri/； 美：/ˈeri/
- #词性/adj  通风的；空气的；轻快的，轻盈的；空中的；快活的，欢乐的；轻率的，轻浮的；虚幻的，不真实的；做作的，高傲的；轻而薄的
# 例句
- Hang it in an airy place .
	- 把它挂在通风的地方。
- A small but airy gym is on the 20th floor .
	- 20层有一个小巧通风的健身房。
- The whole effect is cool , light and airy .
	- 整体效果很酷，轻松而随意。
# 形态
- #形态/word_est airiest
- #形态/word_er airier
