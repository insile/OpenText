---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˌfɪʃəˈnɑːdəʊ/； 美：/əˌfɪʃəˈnɑːdoʊ/
- #词性/n  …迷；酷爱…者
# 例句
- I happen to be an aficionado of the opera , and I love art museums
	- 碰巧我是个歌剧迷，而且我爱去艺术博物馆。
- This is good news for postcard aficionado Drene Brennan .
	- 这对明信片迷杰纳？布雷南来说是个好消息。
- Clay developed a radical style which appalled boxing aficionados .
	- 克莱发展出一种震惊拳击迷的全新风格
# 形态
- #形态/word_pl aficionados
