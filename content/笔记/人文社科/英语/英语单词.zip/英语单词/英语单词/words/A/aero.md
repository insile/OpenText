---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/'eərəʊ/； 美：/'eroʊ/
- #词性/adj  飞机的；飞行的；(指汽车等)流线型的
- #词性/n  飞机；飞行；飞船
# 例句
- High-power microwave generates plasma in aero main dispersion area to absorb and attenuate incident electromagnetic wave .
	- 等离子体是用高功率微波在飞机的主要散射区域产生等离子体以吸收或衰减入射的电磁波。
- This word combines the prefix2 aero - , " relating to airplanes and aviation " and the word metropolis3 , " a large city . " It 's also called an aviation city or an airport city .
	- 这一单词结合了前缀aero-（与飞机和航空有关）和单词metropolis（大都市），也称为航空城市或机场城市。
- Study of an improved aero oil cooling system design method
	- 直升机减速器滑油冷却系统的改进设计方法
