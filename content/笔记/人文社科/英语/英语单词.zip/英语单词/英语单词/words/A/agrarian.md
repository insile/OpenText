---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈɡreəriən/； 美：/əˈɡreriən/
- #词性/adj  农业的；土地的；耕地的
- #词性/n  平均地权论者
# 例句
- The vast majority of developing countries are agrarian in economic , social , and cultural outlook .
	- 从经济，社会和文化方面看，大多数发展中国家都是农业国。
- Research on Value Structure and Evaluation Methods of Agrarian Land in China
	- 我国农用地价值构成及其估价方法研究
- Changes of Political Power in the Change of Agrarian Managing Power
	- 土地治权的变动与政权变迁土地治权变动中的政权变迁
# 形态
- #形态/word_pl agrarians
