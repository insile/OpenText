---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˌæbnɔːˈmæləti/； 美：/ˌæbnɔːrˈmæləti/
- #词性/n  (身体、行为等)不正常，反常，变态，畸形
# 例句
- Oh , I thought you meant something weird , like a physical abnormality .
	- 啊，我还以为你说的什么奇怪的事情，比如医学上的不正常之类的。
- The poor child was born with some abnormality .
	- 这可怜的孩子生下来就有一些不正常。
- Researchers are still trying to isolate the gene that causes this abnormality .
	- 研究人员仍然在试图分离导致这种畸形的基因。
# 形态
- #形态/word_pl abnormalities
