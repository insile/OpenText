---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈflɪkt/； 美：/əˈflɪkt/
- #词性/vt  折磨；使痛苦
# 例句
- There are many illnesses , which afflict old people .
	- 这里有许多的疾病，折磨这些老人。
- The one who afflict me and can 't let me pass is myself .
	- 不放过我的折磨我的是我自己而已；
- About 40 % of the country 's population is afflicted with the disease .
	- 全国40%左右的人口患有这种疾病。
# 形态
- #形态/word_third afflicts
- #形态/word_ing afflicting
- #形态/word_done afflicted
- #形态/word_past afflicted
