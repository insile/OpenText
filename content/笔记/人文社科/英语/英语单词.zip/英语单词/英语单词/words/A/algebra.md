---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈældʒɪbrə/； 美：/ˈældʒɪbrə/
- #词性/n  代数
# 例句
- He would allow John slyly to copy his answers to impossibly difficult algebra questions
	- 他会让约翰偷偷抄下自己对一些极难的代数题的解答。
- She is fascinated by algebra while he considers it meaningless nonsense .
	- 她对代数非常着迷，而他却认为代数毫无意义。
- Middle school students have to learn both algebra and geometry .
	- 中学生必须学代数与几何。
