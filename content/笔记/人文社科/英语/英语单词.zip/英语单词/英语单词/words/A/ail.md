---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/eɪl/； 美：/eɪl/
- #词性/vt  使患病；困扰；使不适；使麻烦；干扰
# 例句
- To redress these wrongs , sweeping new regulatory powers will treat the infirmities that ail us .
	- 全新的监管权力将会治愈困扰我们的病痛、纠正这些错误。
- They discussed the problems ailing the steel industry .
	- 他们讨论了困扰钢铁工业的问题。
- This deal would offer the best possible pick-me-up to the town 's ailing economy .
	- 这笔交易对该镇每况愈下的经济是一服最好的强心剂。
# 形态
- #形态/word_third ails
- #形态/word_ing ailing
- #形态/word_done ailed
- #形态/word_past ailed
