---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/ədˈvaɪs/； 美：/ədˈvaɪs/
- #词性/n  建议；意见；忠告；劝告
# 例句
- If you take my advice you 'll have nothing more to do with him .
	- 你要是听我的劝告，就不要再和他有什么瓜葛。
- Why didn 't you follow my advice ?
	- 你为什么不听我的劝告？
- The emergency services were on hand with medical advice .
	- 随时都有急诊服务，并提供医疗咨询。
