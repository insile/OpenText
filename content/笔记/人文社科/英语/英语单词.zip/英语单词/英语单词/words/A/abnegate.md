---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/v  放弃；拒绝；否认；抛弃；交出
# 例句
- We tumble most of the time for our advantage but not for our disadvantage , Because disadvantage always served as a reminder to us , while advantage deprive us of the right to choose and to abnegate .
	- 许多时候，我们不是跌倒在自己的缺陷上，而是跌倒在自己的优势上，因为缺陷常能给我们以提醒，而优势却常常使我们忘了去选择和放弃。
- Also Discuss Abnegating of a Suit
	- 也论放弃诉讼请求
- To abnegate yourself is the best way to get close to yourself .
	- 舍却自己是寻到自己的最好办法。
# 形态
- #形态/word_third abnegates
- #形态/word_done abnegated
- #形态/word_ing abnegating
- #形态/word_past abnegated
