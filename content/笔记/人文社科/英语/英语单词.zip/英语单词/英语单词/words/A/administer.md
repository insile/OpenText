---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ədˈmɪnɪstə(r)/； 美：/ədˈmɪnɪstər/
- #词性/vt  管理(公司、组织、机构等)；给予，施用（药物等）；给予；提供；执行；治理(国家)；施行；给…一脚（或一拳等）
# 例句
- The plan calls for the UN to administer the country until elections can be held
	- 该方案呼吁联合国来管理该国，直到能进行选举为止。
- He thinks the tax is impossible to administer
	- 他认为税金没法管理。
- Police believe his wife could not have administered the poison .
	- 警方认为他的妻子是不可能下毒的。
# 形态
- #形态/word_third administers
- #形态/word_ing administering
- #形态/word_done administered
- #形态/word_past administered
