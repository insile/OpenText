---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈælkəhɒl/； 美：/ˈælkəhɔːl/
- #词性/n  酒精；乙醇；酒；含酒精饮料
# 例句
- Nobody under 18 is allowed to buy alcohol .
	- 未满18岁者不得买酒。
- I could smell alcohol on his breath .
	- 我闻得到他呼吸中有酒气。
- If possible , you want to avoid alcohol .
	- 你应尽可能避免饮酒。
# 形态
- #形态/word_pl alcohols
