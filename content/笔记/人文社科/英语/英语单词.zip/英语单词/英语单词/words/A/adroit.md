---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdrɔɪt/； 美：/əˈdrɔɪt/
- #词性/adj  机敏的；(尤指待人接物)精明的；干练的
# 例句
- John is an adroit negotiator .
	- 约翰是一位机敏的谈判者。
- She is a remarkably adroit and determined politician .
	- 她是一位异常精明果断的政治家。
- She gave the newsman an adroit reply .
	- 她对记者的回答很机巧。
