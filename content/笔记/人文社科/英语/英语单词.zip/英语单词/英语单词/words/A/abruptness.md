---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性/n  突发性；粗鲁，莽撞
# 例句
- Suddenly Vanamee returned to himself with the abruptness of a blow .
	- 伐那米猛地清醒过来，象挨到了当头一拳似的。
- A Little Understanding about Abruptness Accidents of Environmental Pollution and Emergency Monitoring for Them
	- 对突发性环境污染事故及其应急监测的几点认识
- VBR video signal has the character such as nonlinear , time change and abruptness etc.
	- 视频信号具有时变性、非线性和突发性等特点。
