---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性/adj  地上的；在地上，未被埋葬地，活着
# 例句
- Of the nutrient standing stocks in the aboveground components , 78 % to 97 % were contained in the tree layer .
	- 在地上部分则78%～97%集中在乔木层。
- Plants generally absorb and translocate relatively small amounts of arsenic into aboveground parts .
	- 植物常常将少量的砷吸收和转移到地上部分。
- The relationship between root system of rice and aboveground characteristics and yield
	- 水稻群体根系特征与地上部生长发育和产量的关系
