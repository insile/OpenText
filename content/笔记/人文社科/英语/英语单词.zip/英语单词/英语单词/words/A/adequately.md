---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- #词性/adv  充分；充分地；足够地；适当地
# 例句
- Are you adequately insured ?
	- 你保够了险吗？
- Firstly , they must make certain that their pension needs are adequately catered for
	- 首先，他们得确保他们能获得足够的养老金。
- Within this lecture I cannot pretend to deal adequately with dreams .
	- 在这一次讲座中，我不敢自诩能对梦境作透彻的分析。
