---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性缺失 节制的
# 例句
- They are abstemious and abstain from most of the modern things that other English people , who are now rarely abstentious , enjoy .
	- 他们生活节俭，有意避开其他英国人所享用的大部分现代产品。现代生活节俭的英国人实属罕见。
