---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædətɪv/； 美：/ˈædətɪv/
- #词性/n  (尤指食品的)添加剂；添加物
- #词性/adj  附加的；加法的；加成的；加性的
# 例句
- The biggest to amino acerbity demand still is animal feed additive .
	- 对氨基酸需求量最大的仍是动物饲料添加剂。
- Easer : Printing ink additive used to reduce tack.Examples are thin varnish , reducing oil , etc.
	- 减黏剂：用来降低油墨黏度的添加剂。例如稀光漆，减韧油。
- People can react badly to certain food additives .
	- 人们对某些食品添加剂会严重过敏。
# 形态
- #形态/word_pl additives
