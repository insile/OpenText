---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈækəlaɪt/； 美：/ˈækəlaɪt/
- #词性/n  助手；侍从；随员；襄礼员
# 例句
- And so our most promising acolyte left us .
	- 就这样，我们最有前途的助手离开了我们。
- What do you really know about your acolyte , serenity ?
	- 你了解你的助手吗，serenity？
- To his acolytes , he is known simply as ' the Boss ' .
	- 他被手下人简称为“老板”。
# 形态
- #形态/word_pl acolytes
