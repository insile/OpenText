---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/n  精简；减少；精简；减少
# 例句
- In addition , it discussed essence information 's marking , token adding , length , abridgment , etc.
	- 对精粹信息的标引、加权、长度、删节等进行了讨论。
- This abridgment provides a concise presentation of this masterpiece of Buddhist literature .
	- 这个删节本提供了简明介绍佛教文学的杰作。
- I gave him an abridgment of this whole history , I gave him a picture of my conduct for fifty years in miniature .
	- 我把我全部的历史简略地告诉了他，我让他看到了我五十年来生活的缩影。
