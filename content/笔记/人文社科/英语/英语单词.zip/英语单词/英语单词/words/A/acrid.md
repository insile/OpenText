---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈækrɪd/； 美：/ˈækrɪd/
- #词性/adj  (气、味)辛辣的；刺激的；难闻的
# 例句
- Acrid : Describes a harsh or bitter taste or pungent smell that is due to excess sulfur .
	- 辛辣的：形容一个粗糙或苦的味道又或者是由于过量的硫磺而产生的刺激性气味。
- A tendril-bearing vine of the genus Bryonia having large leaves and small flowers and yielding acrid juice with emetic and purgative properties .
	- 泻根属卷须状藤蔓植物，有大叶子和小花，其辛辣的汁液有催吐和催泻作用。
- The air is thick with acrid smoke from the fires
	- 空气中弥漫着火灾产生的刺鼻浓烟。
