---
tags:
  - 首字母/A
  - 级别/小学
掌握: false
模糊: false
---
# 词义
- 英：/əˈɡen/； 美：/əˈɡen/
- #词性/adv  又一次；再一次；多；增加；再说；再说，另一方面；复原；请再说一遍；返回原处
# 例句
- Prices were cut yet again .
	- 物价再一次降低。
- The accident again raises questions about the safety of the plant .
	- 这起事故再一次引发了人们对于工厂安全性的质疑。
- I would very much like to see you again .
	- 我很想再见到你。
