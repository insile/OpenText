---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈflɪkʃn/； 美：/əˈflɪkʃn/
- #词性/n  折磨；痛苦
# 例句
- This affliction , far from reducing his productivity , drove him more completely into himself .
	- 这种痛苦的折磨，与减少他的创作能力不同，更彻底地深深打击了他。
- Mental illness is not only a terrible affliction . It is also a dreadful economic waste . The deprivation is clear .
	- 精神疾病不仅是一种可怕的折磨，还是一种骇人的经济浪费。
- Hay fever is an affliction which arrives at an early age .
	- 枯草热是年纪较小时会患的一种病。
# 形态
- #形态/word_pl afflictions
