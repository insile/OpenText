---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌæbəˈrɪdʒənl/； 美：/ˌæbəˈrɪdʒənl/
- #词性/n  (尤指澳大利亚的)土著，土人；原住民
- #词性/adj  澳大利亚土著的；(欧洲人到来之前某地区的人、动物等)土著的，土生土长的
# 例句
- What are the three main groups of Aboriginal Peoples ?
	- 三个主要的原住民部落是哪些？
- Legal aid is also provided by Aboriginal Legal Services which operate throughout Australia .
	- 原住民法律事务服务也在全澳大利亚范围内提供法律援助服务。
- Within French-speaking Quebec , anglophone , allophone and Aboriginal minorities also exist .
	- 在讲法语的魁北克省境内也有少数说英语、母语非法语或英语的加拿大人以及土著。
# 形态
- #形态/word_pl aboriginals
