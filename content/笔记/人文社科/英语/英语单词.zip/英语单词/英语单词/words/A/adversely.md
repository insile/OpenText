---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性/adv  不利地；反而
# 例句
- Her health was adversely affected by the climate .
	- 那种气候损害了她的健康。
- Nicotine adversely affects the functioning of the heart and arteries
	- 尼古丁会对心脏及动脉功能造成损害。
- Flower-bud formation may be affected adversely .
	- 反而影响花芽的形成。
