---
tags:
  - 首字母/A
  - 级别/小学
掌握: false
模糊: false
---
# 词义
- 英：/ˌeɪ ˈem/； 美：/ˌeɪ ˈem/
- #词性/abbr  上午；午前(源自拉丁语ante meridiem)；午夜至正午
# 例句
- Guests should vacate their rooms by 10.30 a.m.
	- 旅客应在上午10:30以前腾出房间。
- It starts at 10 a.m.
	- 上午10点开始。
- We didn 't get to bed until 3 a.m.
	- 我们直到凌晨3点才上床睡觉。
