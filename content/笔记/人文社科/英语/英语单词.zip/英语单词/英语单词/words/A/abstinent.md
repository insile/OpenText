---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈæbstɪnənt/； 美：/ˈæbstɪnənt/
- #词性/adj  禁欲的；(因道德、宗教或健康原因对酒等)节制的
# 例句
- People can be abstinent , and it 's not weird .
	- 人是能够禁欲的。这没有什么可奇怪的。
- During treatment , sexual activity should be abstinent .
	- 治疗期间，宜节制房事。
- Exploration of central dopamine transporter and D2 receptor in morphine abstinent rats
	- 吗啡戒断大鼠脑多巴胺转运蛋白及D2受体的研究
