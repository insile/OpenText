---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈɑːftəlaɪf/； 美：/ˈæftərlaɪf/
- #词性/n  死后(灵魂的)生活；阴世
# 例句
- Jews don 't have any clear textual guide to the afterlife .
	- 犹太人没有明确的关于死后生活的文字指南。
- That could have been the end of the story , but the next morning , my husband , ( who doesn 't believe in ghosts or the afterlife ) mentioned he wanted to speak to me about something while we were making the bed .
	- 这时猫一溜烟的跑了。故事到此也许应该就结束了，但是在第二天早晨收拾床时，我丈夫，一个从来不信鬼神、不信阴府来世的人，说他想告诉我点事。
- I think the afterlife is just made up by people .
	- 我觉得来世的说法只是人们编造出来的。
# 形态
- #形态/word_pl afterlives
