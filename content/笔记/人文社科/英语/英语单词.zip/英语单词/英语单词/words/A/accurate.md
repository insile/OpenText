---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈækjərət/； 美：/ˈækjərət/
- #词性/adj  准确的(掷、射、击等)；精确的；正确无误的
# 例句
- Accurate measurement is very important in science .
	- 在科学领域，精确的测量非常重要。
- Doctors can get the wrong impression from even an accurate description .
	- 即便很精确的病历也可能让医生产生错误的印象。
- An accurate diagnosis was made after a series of tests .
	- 准确的诊断是在一系列的检查后作出的。
# 形态
- #形态/word_est most accurate
- #形态/word_er more accurate
