---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌæbəˈrɪdʒəni/； 美：/ˌæbəˈrɪdʒəni/
- #词性/n  土著；澳大利亚土著；原住居民；土人
# 例句
- Decorative Art of Aborigine in Australia
	- 澳大利亚土著装饰艺术
- Wang Ping : A girl and an aborigine put together the whole per-formance , which gave prominence to the humanistic spirit .
	- 王平；一个女孩和一个土著人串起整台晚会，突出了人文精神。
- Genetics Analysis of Shanghai Aborigine with SNPs on Y Chromosome
	- 上海原住民的Y染色体遗传分析
