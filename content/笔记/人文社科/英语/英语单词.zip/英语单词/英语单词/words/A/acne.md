---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈækni/； 美：/ˈækni/
- #词性/n  痤疮；粉刺
# 例句
- Severe shock can bring on an attack of acne
	- 严重的惊吓会造成痤疮突发。
- Research Progress on the Mechanism of Chinese Medicine in Treating Acne
	- 中医药抗痤疮机理研究近况
- Acne often clears up after the first three months of pregnancy .
	- 粉刺在怀孕3个月后往往会自动消失。
