---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/əˈkrɒs/； 美：/əˈkrɔːs/
- #词性/prep  在(身体某部位)上；穿过；在…对过；在…对面；横过；在…各处；从…一边到另一边
- #词性/adv  在对过；在对面；横过；宽；从一边到另一边；从…的一边向…；横写的
# 例句
- There 's a way across the fields .
	- 有一条路穿过田地。
- We left the road and struck off across the fields .
	- 我们下了公路，穿过旷野往前走。
- The map shows the distribution of this species across the world .
	- 地图上标明了这一物种在全世界的分布情况。
