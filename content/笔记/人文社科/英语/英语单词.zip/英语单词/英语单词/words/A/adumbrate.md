---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædəmbreɪt/； 美：/ˈædəmbreɪt/
- #词性/vt  概述；概括说明；勾画轮廓
# 例句
- What symptom is the early days of cancer adumbrates ?
	- 癌症的前期预兆是什么症状
- The recent development adumbrate a world-wide revolution in computer technology .
	- 最新事态的发展预示着一场全球性的计算机技术革命。
- This book shows us the adumbrate of the future .
	- 这本书向我们展示了对未来的勾画。
# 形态
- #形态/word_third adumbrates
- #形态/word_ing adumbrating
- #形态/word_done adumbrated
- #形态/word_past adumbrated
