---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/æf'ɡænɪstæn/； 美：/æf'ɡænɪstæn/
- #词性/n  阿富汗；阿富汗伊斯兰国
# 例句
- He pulled back forces from Mongolia , and he withdrew from Afghanistan .
	- 他从蒙古撤军，并且撤离阿富汗。
- His book about Afghanistan is reviewed here by Anthony Hyman .
	- 安东尼·海曼在此就他那本关于阿富汗的书写了书评。
- The 5th Brigade is now taking 895 Land Warrior ensembles to Afghanistan .
	- 第五旅现在携带895套陆地勇士装备去阿富汗。
