---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæbsəluːtli/； 美：/ˈæbsəluːtli/
- #词性/adv  当然，对极了；(强调真实无误)绝对地，完全地；极其
# 例句
- It was like a monkey 's face , absolutely he was like a monkey .
	- 就像一只猴子的脸，绝对地他像只猴子。
- Civil action ( contract ) whose content is illegal is absolutely invalid in our present legal provisions .
	- 在我国目前的法律规定中，内容违法的民事行为（合同）被绝对地认定为无效。
- Only use your car when absolutely necessary .
	- 非用不可的时候再用你的汽车。
