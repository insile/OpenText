---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈbændən/； 美：/əˈbændən/
- #词性/vt  放弃(信念)；(不顾责任、义务等)离弃，遗弃，抛弃；(不得已而)舍弃，丢弃，离开；停止(支持或帮助)；中止；陷入，沉湎于（某种情感）
- #词性/n  放任；放纵
# 例句
- Their decision to abandon the trip was made because of financial constraints
	- 他们决定放弃这次出游是因为财力有限。
- We had no option but to abandon the meeting .
	- 我们别无选择，只有放弃这次会面。
- The country abandoned its political leaders after the war .
	- 战后该国人民不再拥护他们的政治领袖。
# 形态
- #形态/word_third abandons
- #形态/word_ing abandoning
- #形态/word_done abandoned
- #形态/word_past abandoned
