---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˌædæpˈteɪʃn/； 美：/ˌædæpˈteɪʃn/
- #词性/n  适应；改编本；改写本
# 例句
- The performance of adaptation has increased the creative consciousness with its research .
	- 而改编本的演出也随着其研究的深入和拓展增强了创新意识。
- The conversion of art form between famous work and adaptation is one of the key issues during the masterpiece adaptation .
	- 原著和改编本之间艺术形式上的转换是名著改编关键的问题之一。
- They 're paying you ten grand now for those adaptations of old plays .
	- 他们打算付你一万美元作为改编老剧本的报酬。
# 形态
- #形态/word_pl adaptations
