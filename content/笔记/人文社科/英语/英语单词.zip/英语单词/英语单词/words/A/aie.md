---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性缺失 空中接口演进；艾奥梅；急性感染性心内膜炎；自适应图像增强器；挨饿
# 例句
- The measuring principle hardware configuration and error analysis aie also presented .
	- 并介绍了测量原理、硬件配置及误差分析。
- The follow-up Investigation and Policy Research of AIE 's Graduates
	- 高校毕业生就业跟踪调查及对策分析&以安徽教育学院为例
- In 1990s , the AIE has shown its trend towards global education transformation .
	- 20世纪90年代，美国国际教育体现出向全球教育转型的趋势。
