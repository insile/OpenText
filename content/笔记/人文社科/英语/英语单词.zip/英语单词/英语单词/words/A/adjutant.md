---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædʒʊtənt/； 美：/ˈædʒʊtənt/
- #词性/n  副官
# 例句
- Well , my dear boy , you still want an adjutant 's post ?
	- 啊，亲爱的，怎么样？您总是想当副官吗？
- John Nichols is the adjutant general with the Texas ' National Guard .
	- 约翰·尼科尔斯是得州国民警卫队的副官。
- Adjutant radiation therapy of 6080 Gy was performed on all cases .
	- 术后均予以辅助放射治疗，剂量60~80Gy。
# 形态
- #形态/word_pl adjutants
