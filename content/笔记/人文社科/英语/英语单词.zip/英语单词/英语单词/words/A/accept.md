---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/əkˈsept/； 美：/əkˈsept/
- #词性/v  接受；同意；认可；接纳；承认，承担（责任等）；相信（某事属实）；收受；欢迎；容忍，忍受（困境等）
# 例句
- We cannot accept children above the age of 10 .
	- 我们不能接受10岁以上的儿童。
- I accept his theories , but not without certain qualifications .
	- 我接受他的理论，但并非毫无保留。
- It may take years to be completely accepted by the local community .
	- 也许需要多年方能被当地居民完全接纳。
# 形态
- #形态/word_third accepts
- #形态/word_ing accepting
- #形态/word_done accepted
- #形态/word_past accepted
