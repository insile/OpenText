---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌædvenˈtɪʃəs/； 美：/ˌædvenˈtɪʃəs/
- #词性/adj  偶然的；偶然发生的；非计划中的
# 例句
- The strike was broken , of course , but in the main by a series of adventitious developments .
	- 罢工是中断了，但主要还是由于发生了一系列意外事件。
- The root system size and adventitious root diameter are various ;
	- 根系在大小和不定根直径方面存在变异；
- Study of test method of adventitious virus agent
	- 病毒外源因子检测方法的探讨
