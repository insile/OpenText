---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/ədˈvaɪz/； 美：/ədˈvaɪz/
- #词性/v  建议；通知；提供咨询；提出建议；劝告；忠告；出主意；正式告知
# 例句
- Her mother was away and couldn 't advise her .
	- 她的母亲不在身边，无法向她提出劝告。
- Many doctors advise people living in the countryside .
	- 许多医生都劝告人们住到乡下去。
- You would be well advised to tackle this problem urgently .
	- 你还是抓紧处理这个问题为好。
# 形态
- #形态/word_third advises
- #形态/word_ing advising
- #形态/word_done advised
- #形态/word_past advised
