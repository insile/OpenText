---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌæfekˈteɪʃn/； 美：/ˌæfekˈteɪʃn/
- #词性/n  做作；假装；矫揉造作；装模作样
# 例句
- Lawson writes so well : in plain English , without fuss or affectation .
	- 劳森写得很好：英文通俗易懂，朴实无华又不矫揉造作。
- She did so , at any rate , without affectation .
	- 她这样做至少是毫不矫揉造作。
- He raised his eyebrows with an affectation of surprise .
	- 他扬起双眉装出一副惊奇的样子。
# 形态
- #形态/word_pl affectations
