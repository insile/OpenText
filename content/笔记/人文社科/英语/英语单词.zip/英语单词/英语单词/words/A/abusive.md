---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈbjuːsɪv/； 美：/əˈbjuːsɪv/
- #词性/adj  虐待的；辱骂的；毁谤的；恶语的
# 例句
- Use foul or abusive language towards .
	- 用污秽或辱骂的语言骂。
- If your partner is abusive and alcoholic , then you have a part of your unconscious that is abusive and alcoholic .
	- 1.abusivea.虐待的；滥用的如果你的伙伴是好辱骂的并酗酒的，那么你就有好辱骂且酗酒的无意识部分。
- He became abusive when he was drunk .
	- 他喝醉时就满口脏话骂人了。
