---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/æbˈnɔːml/； 美：/æbˈnɔːrml/
- #词性/adj  不正常的；畸形的；反常的；变态的
# 例句
- Both vaccines also appeared to prevent abnormal , precancerous cell growths found in the cervix , he says .
	- 他说，两种疫苗还可预防子宫颈不正常的癌前细胞的增长。
- Ailurophobia : Abnormal fear of cats
	- 恐猫症：对猫不正常的惧怕
- They thought his behaviour was abnormal .
	- 他们认为他行为反常。
