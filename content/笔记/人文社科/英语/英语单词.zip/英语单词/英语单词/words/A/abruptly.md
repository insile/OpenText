---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈbrʌptli/； 美：/əˈbrʌptli/
- #词性/adv  突然；立刻；出其不意地；猝然；粗暴地；忽然间
# 例句
- She left the room abruptly without explanation .
	- 她未作解释就突然离开了房间。
- The bus stopped abruptly , nearly tipping me out of my seat .
	- 公共汽车突然刹车，差点儿把我从座位上甩出去。
- Abruptly the group ahead of us came to a standstill
	- 我们前面的小组突然停了下来。
