---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əbˈskɒnd/； 美：/əbˈskɑːnd/
- #词性/vi  (携款)潜逃；逃走；逃遁
# 例句
- Afterwards , they sell the ship and the goods and abscond .
	- 然后，他们卖掉船和货物，各自潜逃。
- Or , without buying his freedom , to abscond thither .
	- 或者不赎回自由，而潜逃到那里。
- He was ordered to appear the following day , but absconded
	- 他被传唤于第二天出庭，可是他逃跑了。
# 形态
- #形态/word_third absconds
- #形态/word_ing absconding
- #形态/word_done absconded
- #形态/word_past absconded
