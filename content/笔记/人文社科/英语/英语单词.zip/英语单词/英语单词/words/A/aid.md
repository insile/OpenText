---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/eɪd/； 美：/eɪd/
- #词性/n  援助；帮助；(完成某工作所需的)助手；辅助设备；救援物资；辅助物；援助款项
- #词性/v  援助；帮助
# 例句
- They made a request for further aid .
	- 他们要求再给一些帮助。
- This feature is designed to aid inexperienced users .
	- 这个特色是为帮助没有经验的用户而设计的。
- The new test should aid in the early detection of the disease .
	- 新的化验应该有助于早早检查出这种疾病。
# 形态
- #形态/word_third aids
- #形态/word_ing aiding
- #形态/word_done aided
- #形态/word_pl aids
- #形态/word_past aided
