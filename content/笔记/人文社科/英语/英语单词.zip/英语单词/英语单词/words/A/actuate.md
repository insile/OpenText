---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈæktʃueɪt/； 美：/ˈæktʃueɪt/
- #词性/vt  激励；开动(机器、装置等)；驱使
# 例句
- Then he thinks other way with respect to actuate brain .
	- 于是他就开动脑子想其它门路。
- Two more chains drive the oil pump and the two high-pressure pumps actuate the common rail injection system .
	- 另外两个链条驱动机油泵和两个高压泵开动的共轨喷射系统。
- The flow of current actuates the signal .
	- 电流发出了信号。
# 形态
- #形态/word_third actuates
- #形态/word_ing actuating
- #形态/word_done actuated
- #形态/word_past actuated
