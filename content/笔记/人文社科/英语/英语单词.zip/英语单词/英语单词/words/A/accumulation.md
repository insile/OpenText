---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˌkjuːmjəˈleɪʃn/； 美：/əˌkjuːmjəˈleɪʃn/
- #词性/n  积累；积聚；堆积；堆积物；聚积物
# 例句
- The rate of accumulation decreases with time .
	- 积累的速度随着时间变慢。
- The funds needed will mainly be drawn from accumulation within the enterprise .
	- 所需资金主要取给于企业内部的积累。
- Under the accumulation of time , I expect to mature generally .
	- 在时间的储积下，我期望通常成熟。
# 形态
- #形态/word_pl accumulations
