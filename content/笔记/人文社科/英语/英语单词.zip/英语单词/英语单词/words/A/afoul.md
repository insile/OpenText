---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈfaʊl/； 美：/əˈfaʊl/
- #词性/adj #词性/adv  纠缠着（的）；冲撞着（的）
# 例句
- All of them had run afoul of the law at some time or other .
	- 他们所有人都曾触犯过法律。
- Even tightly regulated countries could run afoul of the directive .
	- 即使监管严格的国家也不一定符合指令要求。
- Whose only crime was to run afoul of some very powerful ,
	- 他唯一做错的就是得罪了某些有权有势
