---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əbˈstenʃn/； 美：/əbˈstenʃn/
- #词性/n  弃权(不投票)；戒；戒除
# 例句
- Abstention is traditionally high in Colombia .
	- 在哥伦比亚，弃权率历来较高。
- Scowcroft met with Dinitz to brief him on the Soviet proposal for a joint abstention .
	- 斯考克罗夫特会见迪尼茨，向上通报苏联关于联合弃权的建议。
- There were 21 votes for and 17 against the motion , with 2 abstentions .
	- 这项动议有21票赞成，17票反对，2票弃权。
# 形态
- #形态/word_pl abstentions
