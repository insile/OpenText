---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbeɪəns/； 美：/əˈbeɪəns/
- #词性/n  搁置；（土地）所有权等的未决，未定，待定
# 例句
- The matter was left in abeyance until Haig saw French .
	- 事情被搁置了起来，直到黑格见到法国人。
- The law was held in abeyance for well over twenty years .
	- 这项法律被搁置了二十多年。
- The threat is likely to remain in abeyance until next year 's meeting in Reykjavik .
	- 这一威胁很可能会一直存在下去，直至明年的雷克雅未克会议。
