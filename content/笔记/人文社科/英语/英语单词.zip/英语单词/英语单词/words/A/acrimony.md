---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈækrɪməni/； 美：/ˈækrɪmoʊni/
- #词性/n  (态度、言辞)尖刻；讥讽
# 例句
- This is the third president I'veserved withand I have never seen this kind of partisan acrimony .
	- 这是第三个我服务的总统，我从来没有见过这种党派之间的尖刻斗争。
- But despite the acrimony both delegations said they will now prepare to start more detail negotiations .
	- 不过虽然双方代表团态度尖刻，但是双方均表示会继续准备进一步协商。
- The dispute was settled without acrimony .
	- 没有唇枪舌剑，这场纠纷就解决了。
