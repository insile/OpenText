---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- #词性/n  醛固酮；醛甾酮，醛固酮
# 例句
- Using aldosterone antagonist in treatment of heart failure
	- 醛甾酮拮抗药在心力衰竭治疗中的应用
- Randomized aldactone evaluation study ( RALES ) showed that adding aldosterone antagonist in the treatment of heart failure may decrease 30 % mortality of all causes .
	- 随机螺内酯评估研究表明在心力衰竭治疗中加用醛甾酮拮抗药可使总死亡率降低30%。
- The principal adrenocortical products are aldosterone , cortisol and dehydroepiandrosterone sulphate .
	- 肾上腺皮质的主要产物为醛固酮、皮质醇和脱氢异雄酮硫酸盐。
