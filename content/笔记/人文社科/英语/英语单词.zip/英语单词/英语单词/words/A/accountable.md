---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/雅思
掌握: false
模糊: false
---
# 词义
- 英：/əˈkaʊntəbl/； 美：/əˈkaʊntəbl/
- #词性/adj  负有责任的；(对自己的决定、行为)负有责任，有说明义务
# 例句
- Sole proprietors are reassuring to customers who believe an individual who is accountable will do a good job .
	- §顾客总是相信一个负有责任的人会把事情做好，因此个体业主可以使顾客放心。
- For the present , however , the more immediate-and more pragmatic-task for administrative law is to evaluate and further refine the doctrines and techniques for making bureaucratic power accountable , without destroying the effectiveness of those administrative agencies considered necessary .
	- 可是目前，行政法的更为直接和更为务实的任务是评估和进一步推敲提炼使行政权力负有责任的各种理论和方法，而无需破坏那些必不可少的行政机构的有效性。
- Someone must be held accountable for the killings .
	- 必须有人要对这些凶杀事件负责。
