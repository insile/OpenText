---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əbˈzɔːb/； 美：/əbˈzɔːrb/
- #词性/vt  吸收（热、光、能等）；吸收(液体、气体等)；承受，承担，对付；理解；使并入；掌握；吞并；同化；耗费，耗去；减轻作用；吸引全部注意力
# 例句
- Black walls absorb a lot of heat during the day .
	- 黑色墙壁在白天吸收大量的热。
- His mind was like a sponge , ready to absorb anything .
	- 他的脑子跟海绵似的，什么都能吸收。
- It 's a lot of information to absorb all at once .
	- 要一下子消化这么多资料，真是很难。
# 形态
- #形态/word_third absorbs
- #形态/word_ing absorbing
- #形态/word_done absorbed
- #形态/word_past absorbed
