---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈsɪdjələs/； 美：/əˈsɪdʒələs/
- #词性/adj  带酸味的
# 例句
- His acidulous remarks towards the mayor put everyone ill at ease .
	- 他对市长尖刻的评论使每个人都不自在。
- It reveals that 30 % acidulous grain alcohol is suitable , superior in the pigment dissolving .
	- 结果表明：30%酸性乙醇是美国地锦色素的较好提取剂
- Treatment of Leaching Acidulous Water in Waste Rock Dump Acid Deposition
	- 煤矿矸石山淋溶酸性水处理
