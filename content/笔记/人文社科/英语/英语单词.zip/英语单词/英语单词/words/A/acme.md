---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈækmi/； 美：/ˈækmi/
- #词性/n  顶点；顶峰；典范
# 例句
- Schubert reached the acme of his skill while quite young .
	- 舒伯特的技巧在他十分年轻时即已达到了顶峰。
- Schencrt reach the acme of his skill while quite young .
	- 舒伯特的技巧在他十分年轻时即已达顶峰。
- His work is considered the acme of cinematic art .
	- 他的作品被认为是电影艺术的巅峰之作。
