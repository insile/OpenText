---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkweɪnt/； 美：/əˈkweɪnt/
- #词性/vt  使熟悉；使了解
# 例句
- To acquaint ( oneself ) with knowledge of a subject . Keep up with the latest developments in science
	- 使熟悉使（自己）对某一主题的知识熟悉熟悉科学上最新的发展
- You will first need to acquaint yourself with the filing system .
	- 你首先需要熟悉文件归档方法。
- The students are already acquainted with the work of Shakespeare .
	- 这些学生已经读过莎士比亚的著作。
# 形态
- #形态/word_third acquaints
- #形态/word_ing acquainting
- #形态/word_done acquainted
- #形态/word_past acquainted
