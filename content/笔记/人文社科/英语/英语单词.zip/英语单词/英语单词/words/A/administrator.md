---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ədˈmɪnɪstreɪtə(r)/； 美：/ədˈmɪnɪstreɪtər/
- #词性/n  管理员；(公司、机构的)管理人员，行政人员
# 例句
- The administrator can add course and students , teachers users .
	- 管理员要能添加课程和学生、教师用户。
- See your local system administrator for help .
	- 请与本地系统管理员联系，寻求他们的帮助。
- He 's a local government administrator , that is to say a civil servant .
	- 他是地方政府的行政官员，也就是公务员。
# 形态
- #形态/word_pl administrators
