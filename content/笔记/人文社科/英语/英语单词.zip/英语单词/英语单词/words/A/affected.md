---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈfektɪd/； 美：/əˈfektɪd/
- #词性/v  影响；使感染；侵袭；使悲伤(或怜悯等)；(感情上)深深打动
- #词性/adj  假装的；做作的
# 例句
- Manufacturing processes may be affected by the functionality of the product .
	- 生产过程可能要受到产品设计目的的影响。
- Changes in farming methods have badly affected employment in the area .
	- 耕作方法的改变严重影响了这个地区的就业。
- People tend to think that the problem will never affect them .
	- 人们往往认为这个问题绝不会影响到他们。
# 形态
- #形态/word_proto affect
