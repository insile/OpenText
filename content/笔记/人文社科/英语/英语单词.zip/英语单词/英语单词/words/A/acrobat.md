---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/雅思
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈækrəbæt/； 美：/ˈækrəbæt/
- #词性/n  杂技演员
# 例句
- The acrobat 's feat took the audience 's breath away .
	- 杂技演员的惊险动作使观众为之咋舌。
- The acrobat could bend himself into a hoop .
	- 这个杂技演员可以把身体蜷曲成圈形。
- The acrobat went through various contortions .
	- 卖艺人把身体作出各种扭歪的姿态。
# 形态
- #形态/word_pl acrobats
