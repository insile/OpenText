---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædəmənt/； 美：/ˈædəmənt/
- #词性/adj  坚决的；坚定的；坚定不移的
- #词性/n  坚硬无比的东西；硬石(指金刚石等)
# 例句
- The view was unanimous and adamant : we must finish the job .
	- 大家的观点是一致和坚定的：我们必须完成任务。
- However , Claudio Ranieri is adamant in support of the Portuguese international .
	- 不过，拉涅利非常坚定的支持这位葡萄牙国脚。
- Eva was adamant that she would not come .
	- 伊娃坚决不来。
