---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkwɪzətɪv/； 美：/əˈkwɪzətɪv/
- #词性/adj  贪婪的；渴求获取财物的
# 例句
- Like many acquisitive conglomerates , it experienced a rapid ascent and sharp fall .
	- 像许多贪婪的企业集团一样，它也经历了大起大落。
- We live in an acquisitive society which views success primarily in terms of material possessions .
	- 我们生活在一个主要以物质财富来衡量成功的贪婪的社会里。
- The most acquisitive firms tend to be engineering groups .
	- 最贪得无厌的公司往往是工程队。
