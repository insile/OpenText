---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌæbsəˈluːʃn/； 美：/ˌæbsəˈluːʃn/
- #词性/n  赦免；赦罪；解罪
# 例句
- Your Eminence , I am a Christian man , and have never yet been refused absolution .
	- 主教阁下，我是个基督徒，从来没被拒绝过赦罪。
- Research on Duality of Absolution Right on the View of Globalization
	- 论全球化视野下我国赦免权的二元化
- She felt as if his words had granted her absolution .
	- 她感觉他的那番话好似给她下了道赦令。
