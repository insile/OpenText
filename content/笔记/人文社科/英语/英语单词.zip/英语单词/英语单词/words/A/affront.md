---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈfrʌnt/； 美：/əˈfrʌnt/
- #词性/n  侮辱；冒犯
- #词性/vt  侮辱；冒犯
# 例句
- She has taken my enquiry as a personal affront .
	- 她将我的询问当成了人身侮辱。
- The play was considered an affront to public morals .
	- 人们认为这出戏侮辱了社会公德。
- He hoped they would not feel affronted if they were not invited .
	- 他希望如果他们没有获得邀请也不要感到受辱。
# 形态
- #形态/word_third affronts
- #形态/word_ing affronting
- #形态/word_done affronted
- #形态/word_pl affronts
- #形态/word_past affronted
