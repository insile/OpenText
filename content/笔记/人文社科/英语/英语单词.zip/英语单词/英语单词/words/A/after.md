---
tags:
  - 首字母/A
  - 级别/小学
掌握: false
模糊: false
---
# 词义
- 英：/ˈɑːftə(r)/； 美：/ˈæftər/
- #词性/prep  (时间)在…后；之后；关于；与…对照；尽管；在(某人)后面；在…后面，仅次于；寻找；鉴于；跟随；追赶；模仿；表示反复不断或一个接着一个
- #词性/conj  在…以后
- #词性/adv  以后；后来；在后面；向后
- #词性/adj  以后的；后来的；靠近 ( 船或飞机 ) 后部的
# 例句
- I think we could all use a drink after that !
	- 我想我们在事情办完之后都得痛快地喝一杯。
- I need time to get my wind back after that run .
	- 我跑过之后需要时间喘口气。
- I 've told you time after time not to do that .
	- 我一再告诉过你不要干那件事。
