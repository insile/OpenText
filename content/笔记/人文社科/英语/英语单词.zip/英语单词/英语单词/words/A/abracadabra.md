---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌæbrəkəˈdæbrə/； 美：/ˌæbrəkəˈdæbrə/
- #词性/int  (表演魔术、施魔法时所念的咒语)阿布拉卡达布拉
- #词性/n  三角形驱病符；胡言乱语
# 例句
- The magic word " abracadabra " was originally intended for the specific purpose of curing hay fever .
	- 魔力术语“咒语”最初适用于治疗枯草热的特殊目的。
- Love is a curse I do not solve abracadabra however .
	- 爱情是场诅咒我却解不开咒语。
- No problem , oh but here is your cake . Abracadabra !
	- 别客气，这是你的蛋糕。
