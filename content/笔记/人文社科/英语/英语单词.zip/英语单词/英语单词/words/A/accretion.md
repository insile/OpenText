---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkriːʃn/； 美：/əˈkriːʃn/
- #词性/n  堆积；积聚(过程)；堆积层；积聚层
# 例句
- A coral reef is built by the accretion of tiny , identical organisms .
	- 珊瑚礁是由许多相同的微生物不断堆积而成。
- An accretion of sediment at the mouth of the river caused serious flooding .
	- 河口堆积物的增加导致河水严重泛滥。
- The script has been gathering editorial accretions for years .
	- 多年来该剧本一直在修改。
# 形态
- #形态/word_pl accretions
