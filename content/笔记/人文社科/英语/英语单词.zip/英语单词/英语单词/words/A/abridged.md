---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbrɪdʒd/； 美：/əˈbrɪdʒd/
- #词性/v  删节(书籍、剧本等)；节略
- #词性/adj  (书或剧本)节略的；删节的
# 例句
- By the way , the author abridged the above-mentioned story .
	- 顺便提一下，作者节略了上述的故事。
- An abridged version of the novel appeared in a magazine .
	- 这部小说的节略版刊登在一份杂志上。
- A long story can be abridged by leaving out unimportant parts .
	- 可将一个冗长故事中无关紧要的部分删去以减少篇幅。
# 形态
- #形态/word_proto abridge
