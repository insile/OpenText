---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əbˈzɔːpʃn/； 美：/əbˈzɔːrpʃn/
- #词性/n  (液体、气体等的)吸收；同化；并入；全神贯注；专心致志；着迷
# 例句
- Vitamin C increases the absorption of iron from food .
	- 维生素C促进食物中铁的吸收。
- Protective gloves reduce the absorption of chemicals through the skin
	- 防护手套可以减少皮肤对化学物质的吸收。
- He was struck by the artists ' total absorption in their work .
	- 他被艺术家对创作的全身心投入所打动。
