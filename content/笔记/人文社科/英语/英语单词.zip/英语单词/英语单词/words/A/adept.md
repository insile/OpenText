---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdept , ˈædept/； 美：/əˈdept , ˈædept/
- #词性/adj  擅长的；熟练的；内行的
- #词性/n  专家，能手
# 例句
- Test cases also serve as adept documentation because they implicitly demonstrate how the code under test works .
	- 测试案例因为暗示了代码在测试工作中是如何工作的，所以还可以充当内行的文档。
- But you 'll see as the semester progresses and you start learning more about musical forms , you 'll become a more adept listener .
	- 但随着学期进行，你会发现你在音乐形式上学到了更多知识，你也会成为更内行的听众。
- The direct marketing industry has become adept at packaging special offers .
	- 直接邮寄广告业在特卖品的包装方面已经变得非常熟练了。
# 形态
- #形态/word_pl adepts
