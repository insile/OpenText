---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈædmərəbl/； 美：/ˈædmərəbl/
- #词性/adj  令人羡慕的；值得赞赏的；好极了；可钦佩的
# 例句
- The symphony is admirable in conception
	- 这支交响乐的构思好极了。
- The symphony is admirable in conception .
	- 构思；设想这支交响乐的构思好极了。
- He made his points with admirable clarity .
	- 他阐述观点明确，值得赞赏。
