---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈsɜːbɪk/； 美：/əˈsɜːrbɪk/
- #词性/adj  尖刻的；严厉的
# 例句
- He sent back an acerbic letter .
	- 他回复了一封尖刻的信。
- Known for his acerbic wit , Chandler makes plenty of jokes at every character 's expense , which includes his father .
	- 钱德勒以尖刻的俏皮话见长，他拿每个人开玩笑，这其中也包括他的父亲。
- The letter was written in her usual acerbic style .
	- 这封信是用她惯常的尖刻语调写的。
