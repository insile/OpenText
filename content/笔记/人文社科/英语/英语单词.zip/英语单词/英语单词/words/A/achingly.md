---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪkɪŋli/； 美：/ˈeɪkɪŋli/
- #词性/adv  (因得不到而)渴望地，痛苦地
# 例句
- The song is achingly beautiful .
	- 那首歌有种哀婉动人的美。
- This achingly tender love story , read out loud by an elderly man every morning for a woman that has no idea what it means , won ’ t end with the closing credits . It will follow you , leaving a bittersweet aftertaste ;
	- 这是一个非常催泪的爱情故事，一位老爷爷每天早上对一个不知道对她意味着什么的老奶奶朗读故事，影片落幕后，留下的苦乐参半的回味不会消失，它会一直跟着你；
- In that hotel , the service is achingly slow .
	- 那家宾馆的服务慢极了。
