---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈiːsθiːt/； 美：/ˈesθiːt/
- #词性/n  唯美主义者；审美家
# 例句
- Nobody will deny that Wilde is an outstanding aesthete .
	- 毫无疑问，王尔德是一位杰出的唯美主义者。
- Based on the above analysis , the paper finally concludes that Oscar Wilde is a paradoxical aesthete as well as a paradoxical moralist .
	- 通过以上分析，本文结论认为奥斯卡王尔德是一个矛盾的唯美主义者，同时他更是一个矛盾的道德家。
- This point of view was put forward by Greek aesthetes more than two thousand years ago .
	- 这是二千多年前希腊的美学家提出来的观点
# 形态
- #形态/word_pl aesthetes
