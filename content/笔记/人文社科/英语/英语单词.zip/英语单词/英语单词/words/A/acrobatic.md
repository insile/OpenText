---
tags:
  - 首字母/A
  - 级别/雅思
掌握: false
模糊: false
---
# 词义
- 英：/ˌækrəˈbætɪk/； 美：/ˌækrəˈbætɪk/
- #词性/adj  杂技；杂技的；杂技演员的
# 例句
- He performed a sensational acrobatic feat .
	- 他表演了一套惊人的杂技功夫。
- The excellent acrobatic performance brought down the house .
	- 精采的杂技表演博得全场喝采。
- This acrobatic move is extremely difficult .
	- 这个杂技动作难度很大。
