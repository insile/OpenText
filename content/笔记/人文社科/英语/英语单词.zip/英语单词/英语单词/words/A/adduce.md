---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdjuːs/； 美：/əˈduːs/
- #词性/vt  举出(证据、理由、事实等)；引证
# 例句
- We can adduce evidence to support the claim .
	- 我们能举出证据支持该说法。
- Let me adduce more evidence .
	- 让我举出更多的证据。
- Several factors have been adduced to explain the fall in the birth rate .
	- 有几个因素已被援引来说明出生率降低的原因。
# 形态
- #形态/word_third adduces
- #形态/word_ing adducing
- #形态/word_done adduced
- #形态/word_past adduced
