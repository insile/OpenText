---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪkərɪdʒ/； 美：/ˈeɪkərɪdʒ/
- #词性/n  面积；英亩数；大块土地
# 例句
- Keep total crop acreage and grain output stable .
	- 稳定粮食播种面积和产量
- The geographical research for change of grain sowing acreage in China
	- 我国粮食播种面积变化的地理研究
- He has sown coffee on part of his acreage
	- 他在自家的部分耕地里种上了咖啡。
# 形态
- #形态/word_pl acreages
