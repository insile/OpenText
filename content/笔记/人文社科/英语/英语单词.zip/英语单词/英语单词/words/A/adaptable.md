---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdæptəbl/； 美：/əˈdæptəbl/
- #词性/adj  能适应的；有适应能力的
# 例句
- Humans are a tough and adaptable species .
	- 人类是一个坚强而又有适应能力的物种。
- " They said fish were the most ancient of the major vertebrate groups , giving them " ample time " to evolve complex , adaptable and diverse behaviour patterns that rivalled those of other vertebrates . "
	- “他们说鱼是最古老的主要脊椎动物，他们有”“足够多的时间”“来进化出复杂多样并且有适应能力的行为模式，与其他脊椎动物相抗衡。”
- Successful businesses are highly adaptable to economic change .
	- 成功的企业对于经济转变的适应能力很强。
