---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædʒɪteɪtɪd/； 美：/ˈædʒɪteɪtɪd/
- #词性/adj  激动的；焦虑不安的
- #词性/v  搅动；使激动；使不安；(尤指为法律、社会状况的改变而)激烈争论，鼓动，煽动；摇动(液体等)；激怒
# 例句
- So , your husband came home agitated .
	- 所以你丈夫激动的回到家。
- After a silence of several minutes , he came towards her in an agitated manner , and thus began :
	- 沉默了几分钟以后，他带着激动的神态走到她跟前说：
- I could not distinguish her words , but she sounded agitated .
	- 我听不清她说的话，但听得出她很紧张不安。
# 形态
- #形态/word_proto agitate
