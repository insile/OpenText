---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ədˈhiːsɪv/； 美：/ədˈhiːsɪv/
- #词性/n  胶粘剂；黏合剂；黏着剂
- #词性/adj  黏合的；黏附的；有附着力的
# 例句
- Study of the Storage Life Time of a Pressure - sensitive Adhesive
	- 压敏胶粘剂的贮存寿命试验研究
- Building Structural Adhesive and its Application and Development
	- 建筑结构胶粘剂及其应用与发展
- Glue the mirror in with a strong adhesive .
	- 用强力胶将镜子固定到位。
# 形态
- #形态/word_pl adhesives
