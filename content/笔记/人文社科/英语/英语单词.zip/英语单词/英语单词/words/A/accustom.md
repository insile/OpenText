---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkʌstəm/； 美：/əˈkʌstəm/
- #词性/v  使习惯(于)；习惯于；使适应
# 例句
- You 'll have to accustom yourself to the new conditions .
	- 你得使自己习惯于新的情况。
- I can accustom myself to cold weather .
	- 我能习惯于冷天气。
- My eyes slowly grew accustomed to the dark .
	- 我的眼睛慢慢适应了黑暗。
# 形态
- #形态/word_third accustoms
- #形态/word_ing accustoming
- #形态/word_done accustomed
- #形态/word_past accustomed
