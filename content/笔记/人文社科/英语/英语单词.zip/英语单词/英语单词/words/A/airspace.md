---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈeəspeɪs/； 美：/ˈerspeɪs/
- #词性/n  领空；(某国的)空域
# 例句
- The proportion of flights being punctual in our country dropped from 72 percent in 2013 to 68 percent last year , which indicates that the traditional airspace management system has hindered the development of the civil aviation industry and has to be reformed as soon as possible .
	- 2014年，我国民航航班正点率为68%，比上一年的72%有所降低。旧的空域管理体制影响了民航业的发展，的确到了“不改不行，非改不可”的地步。
- The Research on the Method of Airspace Evaluation and System Design
	- 空域评估方法研究及其系统设计
- The jet entered Chinese airspace without permission .
	- 那架喷气式飞机未经允许闯入中国领空。
