---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈfɑː(r)/； 美：/əˈfɑːr/
- #词性/adv  在远处；从远处
# 例句
- A lighthouse was flashing afar .
	- 灯塔在远处闪光。
- Someone important may be watching you from afar .
	- 某个重要人物可能在远处注意着你。
- He loved her from afar .
	- 他暗恋着她。
