---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ədˈhɪərənt/； 美：/ədˈhɪrənt/
- #词性/n  (政党、思想的)拥护者，追随者，信徒
- #词性/adj  依附…的；骈生的；(在名词之前的)修饰语的
# 例句
- He was most liberal where money would bring him a powerful or necessary political adherent .
	- 在金钱能够收买一个干练的或者必需的政治拥护者的地方，他是最不惜花钱的。
- Hu Feng has criticized two sides described above as the firm adherent of the May Fourth Movement .
	- 胡风作为五四的坚决拥护者，对上述两方都进行了批判。
- This idea is gaining adherents .
	- 这种观念正在赢得更多的拥护者。
# 形态
- #形态/word_pl adherents
