---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈtʃiːvəbl/； 美：/əˈtʃiːvəbl/
- #词性/adj  可达到的；可获得的
# 例句
- Let 's establish some achievable goals first .
	- 让我们先订下一些可达到的目标。
- Set small , achievable goals .
	- 设定小的、可达到的目标。
- Profits of $ 20m look achievable .
	- 2000万元的利润看来是可以完成的。
