---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdɪktɪv/； 美：/əˈdɪktɪv/
- #词性/adj  上瘾的；使人入迷的
# 例句
- No business likes to admit that it sells addictive poison as a lifestyle choice .
	- 没行业会承认其销售会使人上瘾的毒品作为生活方式的选择。
- Facebook and Instagram have told the BBC that their apps are designed to bring people together and that they never set out to create addictive products .
	- 脸书和照片墙告诉BBC他们的应用程序的设计理念是让人们聚在一起，而从未想开发让人上瘾的产品。
- Crack is a highly potent and addictive derivative of cocaine .
	- 强效纯可卡因是一种药效极强、容易使人上瘾的可卡因制剂。
