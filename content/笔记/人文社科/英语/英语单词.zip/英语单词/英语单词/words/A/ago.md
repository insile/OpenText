---
tags:
  - 首字母/A
  - 级别/小学
掌握: false
模糊: false
---
# 词义
- 英：/əˈɡəʊ/； 美：/əˈɡoʊ/
- #词性/adv  (与动词简单过去时连用)以前
# 例句
- Her parents died a long time ago .
	- 她的父母很早以前就去世了。
- It was on TV not long ago .
	- 电视不久以前播出了这个节目。
- Just a few years ago the picture was very different .
	- 几年前的情况就大不相同。
