---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ədˈmɪtns/； 美：/ədˈmɪtns/
- #词性/n  (建筑物、机构等的)进入权，进入
# 例句
- You know , this sign is just an admittance of our popular culture .
	- 要知道，这个牌子正是一个进入我们的流行文化的标志。
- The big town hall denies admittance to children .
	- 这个城镇大厅不准孩子进入。
- There is no admittance without a security pass .
	- 无保安通行证不得入内。
