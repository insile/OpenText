---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌæfəˈdeɪvɪt/； 美：/ˌæfəˈdeɪvɪt/
- #词性/n  宣誓书；附誓书面证词
# 例句
- Affidavit on the rights of public employees ;
	- 公职人员权利宣誓书；
- There was an affidavit of support submitted and photocopy of a bank statement .
	- 那是一份表示支持的宣誓书和一张充分的银行证书复印件。
- I gave an affidavit to the judge about the accident I witnessed .
	- 我向法官提交了一份关于我目击的事故的证词。
# 形态
- #形态/word_pl affidavits
