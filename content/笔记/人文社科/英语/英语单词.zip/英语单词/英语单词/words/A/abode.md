---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbəʊd/； 美：/əˈboʊd/
- #词性/n  住所；家
- #词性/v  “abide”的过去式和过去分词
# 例句
- I went round the streets and found his new abode .
	- 我走街串巷找到了他的新住所。
- They still dwelt in their old abode .
	- 他们仍然怀念过去的住所。
- You are most welcome to my humble abode .
	- 竭诚欢迎光临寒舍。
# 形态
- #形态/word_pl abodes
