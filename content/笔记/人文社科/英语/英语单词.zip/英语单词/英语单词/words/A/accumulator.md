---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈkjuːmjəleɪtə(r)/； 美：/əˈkjuːmjəleɪtər/
- #词性/n  累加器；蓄电池；累计下注(每赢一次即押于下一轮赌博)
# 例句
- The new scheme is implemented by a new dynamic accumulator .
	- 该方案是利用一个新的动态累加器来实现的。
- To form the results of an operation in an accumulator .
	- 在累加器中形成运算结果。
- Improvement of energy saving in performance test system of hydraulic accumulator
	- 液压蓄能器性能试验系统的节能改进
