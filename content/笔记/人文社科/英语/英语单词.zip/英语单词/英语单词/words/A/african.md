---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæfrɪkən/； 美：/ˈæfrɪkən/
- #词性/adj  非洲的
- #词性/n  非洲人(尤指黑人)
# 例句
- Many African tribes believe in reincarnation .
	- 许多非洲的部落都相信人会转世。
- But African cities are different .
	- 但是非洲的城市不是这样的。
- It was the first time I had set foot on African soil .
	- 那是我第一次踏上非洲大地。
# 形态
- #形态/word_pl Africans
