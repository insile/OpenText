---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- #词性/n  附件；帮凶；帮助犯；同谋犯；从犯；装饰品
- #词性/adj  副的，辅助的；从犯的，帮凶的，同谋的
# 例句
- The connecting device is used to connect the hair nursing accessary and the corresponding handle , the handle is provided with a heating device and a blowing device .
	- 所述的连接装置用于把所述的头发护理附件与所述的对应的手柄相连接，所述的手柄设有加热装置和吹气装置。
- On the other hand , she accepted the male power consciousness consciously and became an accessary to the male power thought .
	- 另一方面她又自觉地接受男权意识，成为男权意识的帮凶和走卒。
- Effect and significance of overt atrioventricular accessary pathway on ventricular high frequency electric activities
	- 房室显性旁道对心室高频电活动的影响
