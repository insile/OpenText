---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪlə/； 美：/ˈeɪlə/
- #词性/abbr  American Library Association 美国图书馆协会
- #词性/n  【生】翼；翼状部
# 例句
- The serum ala - nine transaminase activity increased markedly in the I \/ R groups ( P < 0.01 ) .
	- 血清丙氨酸转氨酶活性在肠缺血再灌注后各组都有明显升高（P＜0.01）。
- The absorption peak was at 230 nm . The concentrations of GLY , PRO and ALA were highest by amino acid analysis .
	- Ⅱ型胶原最大吸收峰为230nm，氨基酸成分分析显示甘氨酸、脯氨酸和丙氨酸含量最高。
- Design Optimization of Synchronous Machine with a High density ALA Rotor
	- 高密度轴向迭片式ALA转子同步电机的优化设计
