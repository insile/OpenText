---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈækses/； 美：/ˈækses/
- #词性/n  (使用或见到的)机会，权利；通道；通路；入径
- #词性/vt  访问，存取(计算机文件)；进入；到达
# 例句
- Does the hotel have wheelchair access ?
	- 这家旅馆有轮椅通道吗？
- The only road access is a tortuous mountain route .
	- 唯一的陆路通道是一条蜿蜒的山道。
- Students must have access to good resources .
	- 学生必须有机会使用好的资源。
# 形态
- #形态/word_third accesses
- #形态/word_ing accessing
- #形态/word_done accessed
- #形态/word_past accessed
