---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/adj  （尤指临死前）极度痛苦的，濒死痛苦的，呻吟待毙的；临终的，临死前的；死期的
# 例句
- Emergency Nursing of 2 Agonal Patients with Over 1 \/ 4 Seriously Damaged Body
	- 超1\/4躯体严重毁损濒死病人的急救护理2例
- He uses them in conjunction with the hex agonal configuration in order to pick the correct and most efficient way to develop the effect .
	- 他利用它们与十六进位濒死的配置，以便选择正确的和最有效的方式发展的影响。
- The final stage of the disease arrived when a vessel was eroded by the disease process and hemorrhage within the lungs produced the agonal death .
	- 疾病的最后的舞台当一个容器是侵蚀的由时，到达了疾病过程并且在肺以内的出血生产了濒死死亡。
