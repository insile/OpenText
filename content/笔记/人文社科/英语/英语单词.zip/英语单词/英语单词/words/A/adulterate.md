---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdʌltəreɪt/； 美：/əˈdʌltəreɪt/
- #词性/vt  (在饮食中)掺假；掺杂
- #词性/v  掺假
- #词性/adj  通奸的；伪的；搀假的
# 例句
- Optimization of Sensors Array as an Electronic Nose in Identifying Adulterate Milk
	- 检测掺假牛奶的电子鼻传感器阵列的优化
- Effect of Adulterate and the Temperature of Processing of Honey on the Starch Diastatic Number
	- 掺假及加工处理温度对蜂蜜淀粉酶值的影响
- The food had been adulterated to increase its weight
	- 食物被掺了杂质以增加分量。
# 形态
- #形态/word_third adulterates
- #形态/word_ing adulterating
- #形态/word_done adulterated
- #形态/word_past adulterated
