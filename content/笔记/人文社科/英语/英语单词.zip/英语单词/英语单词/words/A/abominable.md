---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbɒmɪnəbl/； 美：/əˈbɑːmɪnəbl/
- #词性/adj  可恶的；令人憎恶的；令人厌恶的；极其讨厌的
# 例句
- Can such abominable pride as his , have ever done him good ?
	- 象他这种可恶的傲慢，对他自己有什么好处？
- If ever a man smelt fever and dysentery , it was in that abominable anchorage .
	- 如果有人曾闻过热病和痢疾的气味，那就只有这可恶的锚地了。
- The judge described the attack as an abominable crime .
	- 法官称那次袭击为令人发指的罪行。
