---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈæɡrɪɡət , ˈæɡrɪɡeɪt/； 美：/ˈæɡrɪɡət , ˈæɡrɪɡeɪt/
- #词性/adj  总计的；总数的
- #词性/n  (可成混凝土或修路等用的)骨料，集料；合计；总数
- #词性/vt  合计；总计
# 例句
- Portfolio management focuses attention at an aggregate level .
	- 投资组合管理关注点在总计的层次上。
- They won 4 – 2 on aggregate .
	- 他们以总分4:2获胜。
- The scores were aggregated with the first round totals to decide the winner .
	- 此次得分与第一轮所得总分合计决出胜者。
# 形态
- #形态/word_third aggregates
- #形态/word_ing aggregating
- #形态/word_done aggregated
- #形态/word_pl aggregates
- #形态/word_past aggregated
