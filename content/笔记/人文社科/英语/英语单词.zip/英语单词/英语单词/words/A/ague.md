---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪɡjuː/； 美：/ˈeɪɡjuː/
- #词性/n  疟疾
# 例句
- Q.How do the Chinese think ague arises ?
	- 中国人认为疟疾是怎样产生的呢？
- Artemisia annua is Chinese traditional medicine and raw material for the anti-malaria drug , in which artemisinin is an effective composition against ague .
	- 黄花蒿（Artemisiaannua）是我国的传统中药，其有效成分青蒿素是治疗疟疾的特效药。
- Quartan ague kill old men , and cure young .
	- 三日疟，青年能治好，老人。
