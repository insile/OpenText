---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性缺失 警告的；劝告的；训诫的
# 例句
- Accordingly , the literature in English that has come down to us from this period ( 1150-1250 ) is almost exclusively religious or admonitory .
	- 因此，从这一时期（1150&1250）流传下来给我们的用英语写的作品几乎单一地是关于宗教或劝告的。
- The Supervisory and Admonitory System in Ancient China 4 . Statistics on containers and management of daily accounts .
	- 中国古代的台、谏制度（4）集装箱的统计及台账管理。
- The Admonitory Cases Applied as Admonish for Teaching of Orthopaedic
	- 教学警示病例在骨科教学中的应用与思考
