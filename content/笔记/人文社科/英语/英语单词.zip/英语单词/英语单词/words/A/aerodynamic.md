---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/ˌeərəʊdaɪˈnæmɪk/； 美：/ˌeroʊdaɪˈnæmɪk/
- #词性/adj  空气动力学的；(汽车等)流线型的，符合空气动力学原理的
# 例句
- Now the company is trying to meet rising fuel economy standards & thus the more aerodynamic styling .
	- 如今，这家公司正在努力满足不断提升的燃油经济标准&因此，也就产生更加符合空气动力学的设计风格。
- Secondly , the aerodynamic method , is applied to the original simulation system for vehicle speed control , the vehicle is more smooth and real .
	- 其次，将空气动力学的方法实现后，应用到原仿真系统的车辆的速度控制上来，使车辆运动更加平滑和真实。
- The secret of the machine lies in the aerodynamic shape of the frame .
	- 该机器的精妙之处在于其构架呈流线型。
