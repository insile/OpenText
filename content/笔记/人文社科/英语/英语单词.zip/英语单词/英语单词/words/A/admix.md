---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/v  混合（和）（with）；掺杂（合）
# 例句
- Study of admix carboxylate oil flooding systems (ⅰ) & for high acid value oil
	- 混合羧酸盐复合驱油体系的研究（Ⅰ）&针对高酸值原油
- We make detailed analysis to the dynamics characters of admix network and contrast to scale-free network model and random network model . The result is that admix network has stronger robustness and anti-ruin ability .
	- 详细分析了混合网络的动力学特性，并将新的网络模型与无标度网络模型和随机网络模型的动力学特性进行对比，发现混合网络具有很强的鲁棒特性和抗毁能力。
- Experiment and Research on Anchor Grouting Material Admixed with Polypropylene Fiber
	- 聚丙烯纤维锚固灌浆材料试验研究
# 形态
- #形态/word_third admixes
- #形态/word_done admixed
- #形态/word_ing admixing
- #形态/word_past admixed
