---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/六级
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈfɪlieɪt , əˈfɪliət/； 美：/əˈfɪlieɪt , əˈfɪliət/
- #词性/v  使附属；与…有关；加入；使隶属，使并入(较大的团体、公司、组织)；为…工作
- #词性/n  附属机构；分支机构；分公司；分会
# 例句
- If we affiliate , we will have a better chance to win .
	- 如果我们加入的话，赢的可能性更大。
- But Yulin has allowed the Black Dragon Temple to affiliate itself with the government-sponsored Taoist Association .
	- 但是榆林允许黑龙潭庙加入由政府资助的道教协会，这就给他了合法的外衣。
- The group is not affiliated to any political party .
	- 该团体不隶属任何政党。
# 形态
- #形态/word_third affiliates
- #形态/word_ing affiliating
- #形态/word_done affiliated
- #形态/word_pl affiliates
- #形态/word_past affiliated
