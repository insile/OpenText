---
tags:
  - 首字母/A
  - 级别/小学
掌握: false
模糊: false
---
# 词义
- 英：/əˈfreɪd/； 美：/əˈfreɪd/
- #词性/adj  害怕的；害怕，畏惧(可能受伤害、受苦)；担心(会发生某事)；担心，生怕(将发生不快、不幸或危险的事)
# 例句
- There 's nothing to be afraid of .
	- 没有什么要害怕的。
- That 's what l 'm afraid of .
	- 这也是我所害怕的。
- People are often afraid of things they don 't understand .
	- 人往往对自己不懂的东西感到恐惧。
