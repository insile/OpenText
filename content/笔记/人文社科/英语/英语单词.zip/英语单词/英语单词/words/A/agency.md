---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪdʒənsi/； 美：/ˈeɪdʒənsi/
- #词性/n  机构；(政府的)专门机构；(尤指)代理机构；服务机构；经销机构
# 例句
- The agency has lost several of its most important accounts .
	- 这家代理机构失去了几家最重要的老客户。
- The agency is voluntary and not run for profit .
	- 这个机构是义务性的，不是为了赢利。
- The agency provided me with a steady stream of work .
	- 这介绍所让我不断有活干。
# 形态
- #形态/word_pl agencies
