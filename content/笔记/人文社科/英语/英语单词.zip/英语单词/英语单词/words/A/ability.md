---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/əˈbɪləti/； 美：/əˈbɪləti/
- #词性/n  能力；才能；本领；才智
# 例句
- What criteria are used for assessing a student 's ability ?
	- 用什么标准来评定一个学生的能力？
- His outstanding ability earned him a place on the team .
	- 他非凡的能力为他在队中赢得了一席之地。
- The system has the ability to run more than one program at the same time .
	- 该系统能够同时运行一个以上的程序。
# 形态
- #形态/word_pl abilities
