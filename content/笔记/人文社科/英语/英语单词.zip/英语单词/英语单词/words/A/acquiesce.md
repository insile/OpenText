---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌækwiˈes/； 美：/ˌækwiˈes/
- #词性/vi  默许；默认；顺从；默然接受
# 例句
- Steve seemed to acquiesce in the decision
	- 史蒂夫好像默认了这个决定。
- It is the law of our existence ; and we must acquiesce .
	- 这是我们的存在要随顺的法则；我们只能默认它。
- Senior government figures must have acquiesced in the cover-up .
	- 政府高级官员必然已经默许掩盖真相。
# 形态
- #形态/word_third acquiesces
- #形态/word_ing acquiescing
- #形态/word_done acquiesced
- #形态/word_past acquiesced
