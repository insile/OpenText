---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkɒmədeɪt/； 美：/əˈkɑːmədeɪt/
- #词性/v  容纳；顺应，适应（新情况）；考虑到；顾及；帮忙；为…提供空间；为(某人)提供住宿(或膳宿、座位等)
# 例句
- A new office block was built to accommodate the overflow of staff .
	- 新建了一座办公大楼以便容纳多出的员工。
- Leeds Prison is reported to have almost double the number of prisoners it 's designed to accommodate .
	- 据报道利兹监狱里犯人的数量几乎已达该监狱设计可容纳人数的两倍了。
- I needed to accommodate to the new schedule .
	- 我需要适应新的时间表。
# 形态
- #形态/word_third accommodates
- #形态/word_ing accommodating
- #形态/word_done accommodated
- #形态/word_past accommodated
