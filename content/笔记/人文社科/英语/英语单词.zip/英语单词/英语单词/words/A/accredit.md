---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkredɪt/； 美：/əˈkredɪt/
- #词性/vt  授权；委任，委派(某人为大使等)；认为(某事为某人所说、所做)；正式认可；把…归于
# 例句
- To this , use accredit statement is a very good processing means .
	- 对此，使用授权声明是一个很好的处理方式。
- The United States Department Education does not accredit schools .
	- 美国教育部并不给学校授权。
- Institutions that do not meet the standards will not be accredited for teacher training .
	- 没有达标的大专院校不会获得教师培训的资格。
# 形态
- #形态/word_third accredits
- #形态/word_ing accrediting
- #形态/word_done accredited
- #形态/word_past accredited
