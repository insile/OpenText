---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈbɪzməl/； 美：/əˈbɪzməl/
- #词性/adj  糟糕的；糟透的；极坏的
# 例句
- But China 's systemic food safety failures aren 't without precedent : if you go back a century , Britain and the U.S. overcame the same abysmal food records .
	- 不过，类似中国这样系统性的食品安全问题并非没有先例：早在一个世纪以前，英国和美国也曾遭遇过同样糟糕的食品安全问题。
- The passenger jet crash represents the latest blow for Nigeria 's beleaguered aviation industry , which in recent years had made strides in improving an abysmal air safety record .
	- 此次客机失事是对尼日利亚陷入困境的航空业的最新打击。近年来，尼日利亚在改善其糟糕的航空安全纪录方面取得了巨大进步。
- The general standard of racing was abysmal .
	- 竞赛总体水平极糟。
