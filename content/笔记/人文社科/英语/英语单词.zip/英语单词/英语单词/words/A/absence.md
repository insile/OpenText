---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæbsəns/； 美：/ˈæbsəns/
- #词性/n  不在；缺乏；不存在；缺席
# 例句
- There has been much gossip about the possible reasons for his absence
	- 关于他缺席的原因有很多传言。
- A military court sentenced him to death in his absence
	- 一所军事法庭在他缺席的情况下判处他死刑。
- The decision was made in my absence .
	- 这个决定是我不在的时候作出的。
# 形态
- #形态/word_pl absences
