---
tags:
  - 首字母/A
  - 级别/六级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkjuːtli/； 美：/əˈkjuːtli/
- #词性/adv  (描述不快的感觉)极其，强烈地；强烈意识到；深深感觉到
# 例句
- After her mother 's death , she became acutely aware of her own mortality .
	- 她母亲去世后，她开始强烈意识到自己的生命是有限的。
- It was an acutely uncomfortable journey back to London .
	- 那是一次极其痛苦的返回伦敦的旅行。
- He became acutely conscious of having failed his parents .
	- 他深深感到自己辜负了父母的期望。
