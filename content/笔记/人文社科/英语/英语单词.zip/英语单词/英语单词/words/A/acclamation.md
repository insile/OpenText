---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌækləˈmeɪʃn/； 美：/ˌækləˈmeɪʃn/
- #词性/n  欢呼；喝彩；欢迎；(口头表决)拥护，赞成
# 例句
- Honor comes in a continuous stream and acclamation keeps lasting .
	- 荣誉纷至沓来，喝彩经久不息。
- The news was greeted with considerable popular acclamation .
	- 消息赢得了相当普遍的欢呼。
- The decision was taken by acclamation .
	- 该决议是经口头表决而作出的。
# 形态
- #形态/word_pl acclamations
