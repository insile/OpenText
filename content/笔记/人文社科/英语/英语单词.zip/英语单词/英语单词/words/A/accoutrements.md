---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkuːtrəmənts/； 美：/əˈkuːtrəmənts/
- #词性/n  (某项活动所需的)装备，配备
# 例句
- I love stationery and all the accoutrements of writing .
	- 我爱文具以及所有的书写的工具装备。
- The soldier is checking his accoutrements when he hear the gun shoot .
	- 听到枪响时，这个士兵正在检查他的装备。
- I loved stationery and all the accoutrements of writing .
	- 我喜爱信笺信封和所有文房用具。
# 形态
- #形态/word_proto accoutrement
