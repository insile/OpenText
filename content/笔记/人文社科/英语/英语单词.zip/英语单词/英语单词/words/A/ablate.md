---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/v  烧（消，腐）蚀；剥（脱）落；（融化，蒸发）掉；风化；切开（除）；使除去；使消除
# 例句
- Effect of graphitization degree on the arc ablate rate of different cabon slide materials
	- 炭滑板的石墨化度对电弧烧蚀速率的影响
- Laser marking is a kind of technique using heat effect of laser to ablate meterials on object surface so as to leave over permanent press .
	- 激光打标是利用激光的热效应烧蚀掉物体表面材料从而留下永久标记的技术。
- Effect of light field force on transportation behavior of ablated materials
	- 光场力对烧蚀物时空分布的影响
# 形态
- #形态/word_third ablates
- #形态/word_done ablated
- #形态/word_ing ablating
- #形态/word_past ablated
