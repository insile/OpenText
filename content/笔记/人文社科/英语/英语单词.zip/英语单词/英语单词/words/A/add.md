---
tags:
  - 首字母/A
  - 级别/中考
掌握: false
模糊: false
---
# 词义
- 英：/æd/； 美：/æd/
- #词性/v  添加；添加（特色）；增加；加；把…加起来，计算…的总和，把…相加；补充说；继续说
- #词性/n  添加物；添加的内容
# 例句
- Add tomato paste , salt and pepper to taste .
	- 酌量添加番茄酱、盐和胡椒粉。
- Here you can add and remove deployable languages and retail products .
	- 您可以在这儿添加和删除可部署语言和零售产品。
- Add three parts wine to one part water .
	- 一份水兑上三份葡萄酒。
# 形态
- #形态/word_third adds
- #形态/word_ing adding
- #形态/word_done added
- #形态/word_past added
