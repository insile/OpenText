---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˌædəˈreɪʃn/； 美：/ˌædəˈreɪʃn/
- #词性/n  崇拜；爱慕；热爱；敬慕
# 例句
- Ah , think of the original difficult life , could it be said that we should not have pure adoration and benedictory prayer in hearts ?
	- 想一想啊，对原本艰难的生命，难道我们不该深怀纯净的热爱与祝祷吗？
- After all , Lin is going to the team that forever won the adoration of Chinese basketball fans by helping homegrown basketballer Yao Ming become a global megastar .
	- 毕竟，林书豪即将加入的火箭队曾帮助中国球员姚明成长为国际巨星，并因此赢得了中国球迷永远的热爱。
- The painting is called ‘ Adoration of the Infant Christ ’ .
	- 这幅画叫做《朝拜耶稣圣婴》。
