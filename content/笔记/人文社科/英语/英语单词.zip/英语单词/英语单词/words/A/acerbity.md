---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈsɜːbəti/； 美：/əˈsɜːrbəti/
- #词性/n  酸涩；辛辣尖刻的幽默
# 例句
- Before why crying is nose acerbity acerbity ?
	- 为什么在哭之前鼻子会酸酸的呢？
- The biggest to amino acerbity demand still is animal feed additive .
	- 对氨基酸需求量最大的仍是动物饲料添加剂。
- The research of soybean adipose acerbity based on NIR technology
	- 基于近红外分析技术检测大豆脂肪酸含量的研究
