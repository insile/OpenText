---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈækjəmən/； 美：/ˈækjəmən/
- #词性/n  敏锐；精明
# 例句
- He is a man of considerable business acumen .
	- 他是一个做生意很精明的人。
- His business acumen helped him to succeed where others had failed .
	- 他在商业上的敏锐帮他在其他人失败的地方获得成功。
- His sharp business acumen meant he quickly rose to the top .
	- 他精明的商业头脑令其青云直上。
