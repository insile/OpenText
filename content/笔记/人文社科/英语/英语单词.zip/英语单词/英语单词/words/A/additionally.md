---
tags:
  - 首字母/A
  - 级别/托福
掌握: false
模糊: false
---
# 词义
- 英：/əˈdɪʃənəli/； 美：/əˈdɪʃənəli/
- #词性/adv  另外；此外；进一步；额外地；在更大程度上
# 例句
- You can pay bills over the Internet . Additionally , you can check your balance or order statements
	- 可以在网上支付账单。此外，还能查对余额或订货结算单。
- Additionally , they should be allowed to teach , and be rewarded for doing it well .
	- 此外，他们应该可以自由授课，并会因为做得好而得到奖励。
- He will sign a personal guarantee to additionally secure the loan .
	- 他将签订一个个人担保，以此为贷款多加一层保障。
