---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkʌmplɪʃ/； 美：/əˈkɑːmplɪʃ/
- #词性/vt  完成
# 例句
- She failed to accomplish the task because she was in poor health .
	- 她因健康状况不佳而未能完成任务。
- We will manage to accomplish the task in time even though it is difficult .
	- 纵然任务艰巨，我们也要及时完成。
- The first part of the plan has been safely accomplished .
	- 计划的第一部分已顺利完成。
# 形态
- #形态/word_third accomplishes
- #形态/word_ing accomplishing
- #形态/word_done accomplished
- #形态/word_past accomplished
