---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈækjərəsi/； 美：/ˈækjərəsi/
- #词性/n  准确(性)；精确(程度)
# 例句
- I 'm a bit of a stickler for accuracy
	- 我总是要求精确。
- There is need to check the accuracy of these figures .
	- 有必要核对一下这些数字的精确性。
- They questioned the accuracy of the information in the file .
	- 他们怀疑档案中信息的正确性。
