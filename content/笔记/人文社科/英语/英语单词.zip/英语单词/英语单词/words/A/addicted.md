---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈdɪktɪd/； 美：/əˈdɪktɪd/
- #词性/adj  成瘾；上瘾的；上瘾；有瘾；入迷
# 例句
- After you force yourself to eat it , you get addicted to it .
	- 强迫自己吃了它以后，你就是会上瘾的。
- I could easily become addicted to these chocolates !
	- 这些巧克力我很容易吃上瘾的！
- He 's addicted to computer games .
	- 他迷上了电脑游戏。
# 形态
- #形态/word_proto addict
