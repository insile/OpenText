---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/adj  即兴的；侥幸的，偶然的
# 例句
- Your experience of speculation makes you have aleatory thought .
	- 你投机成功的经验，让你经常存有侥幸的心理。
- In engineering practice , both aleatory uncertainty and epistemic uncertainty often exist .
	- 在实际工程情况中，往往同时存在随机和认知不确定性。
- The uncertainty nature of aleatory contract determines that the principle of utmost good faith should be applied .
	- 射聿合同的射幸性决定了其订立必须遵循最大诚信原则。
