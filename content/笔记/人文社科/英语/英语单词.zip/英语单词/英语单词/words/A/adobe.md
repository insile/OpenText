---
tags:
  - 首字母/A
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdəʊbi/； 美：/əˈdoʊbi/
- #词性/n  土砖；(建筑用)黏土；黏土坯；土砖建筑物
# 例句
- Adobe bricks must drived dried completely before are used .
	- 土坯砖块使用前一定要完全干燥。
- They live in an adobe house .
	- 他们住在一间土坯屋里。
- Adobe 's latest Emoji Trend report also examined the three most misunderstood emojis in the world . The " eggplant " symbol edged out the " peach " and the " clown " emojis respectively as the most confusing for users .
	- 这份最新的报告分析了全球最让人迷惑的三种表情符号：“茄子”险胜“桃子”和“小丑”，成为最让网友感到困惑的表情符号。
# 形态
- #形态/word_pl adobes
