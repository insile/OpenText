---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæktʃuəli/； 美：/ˈæktʃuəli/
- #词性/adv  (礼貌地纠正他人)实际上；事实上；确实，说实在的；(在口语中用于强调事实)的确；(表示想法与事实不一致因而惊奇)竟然；真实地
# 例句
- Actually , it would be much more sensible to do it later .
	- 事实上，以后再办这件事可能要明智得多。
- People don 't realize how serious this recession has actually been
	- 人们没有意识到这次经济衰退事实上有多严重。
- There are lots of people there who can actually help you .
	- 那里有很多人可以真正帮上你的忙。
