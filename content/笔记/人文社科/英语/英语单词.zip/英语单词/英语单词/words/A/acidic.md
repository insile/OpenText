---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈsɪdɪk/； 美：/əˈsɪdɪk/
- #词性/adj  酸的；很酸的；酸性的
# 例句
- Acidic table wines may contain some residual sugar to balance the palate .
	- 进餐时喝的略酸的淡葡萄酒可能含有一些残余糖分来平衡味觉。
- Voila , a more acidic ocean .
	- 瞧，一个更酸的海洋就此形成。
- Some fruit juices are very acidic .
	- 有些果汁酸得很。
