---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈdæptɪv/； 美：/əˈdæptɪv/
- #词性/adj  适应的；有适应能力的
# 例句
- Establish Adaptive Examination System for High Professional Education
	- 建立与高职教育相适应的考试机制
- The change of lending technology directly reduces the adaptability of traditional loan pricing theories , and the SME loans marked with relationship lending need an adaptive pricing method .
	- 贷款技术类型的改变直接导致了传统贷款定价理论的适用性降低，中小企业贷款的关系型贷款属性需要与之相适应的贷款定价方法。
- Societies need to develop highly adaptive behavioural rules for survival .
	- 社会需要发展具有高度适应性的生存行为规则。
