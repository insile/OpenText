---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈædld/； 美：/ˈædld/
- #词性/adj  腐坏的；头脑糊涂的；变质的；昏庸的
- #词性/v  使不能清晰地思考；使糊涂
# 例句
- Being in love must have addled your brain .
	- 坠入爱河必已使你神魂颠倒。
- I suppose the shock had addled his poor old brain .
	- 我估摸这个打击已经把他那可怜的脑袋瓜搞糊涂了。
- You 're talking like an addled romantic .
	- 你说话像个糊里糊涂耽于幻想的人。
# 形态
- #形态/word_proto addle
