---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ədˈventʃərəs/； 美：/ədˈventʃərəs/
- #词性/adj  冒险；惊险的；有冒险精神的；(指事物、方法、思想)新奇的；大胆开拓的；刺激不断的；充满新鲜事物的
# 例句
- He had always wanted an adventurous life in the tropics .
	- 他一直想到热带地区过冒险的生活。
- He was a man of decisive action and an adventurous disposition .
	- 他是一个行动果断又爱冒险的人。
- Many teachers would like to be more adventurous and creative .
	- 许多教师愿意更加进取，更富创造性。
