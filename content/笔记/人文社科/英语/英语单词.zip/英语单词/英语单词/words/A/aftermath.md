---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈɑːftəmæθ/； 美：/ˈæftərmæθ/
- #词性/n  (战争、事故、不快事情的)后果，创伤
# 例句
- The aftermath of war is hunger and disease .
	- 战争的后果是饥饿与疾病。
- He had to endure the aftermath of the accident .
	- 他不得不忍受这次事故的后果。
- A lot of rebuilding took place in the aftermath of the war .
	- 战后进行了大量的重建工作。
# 形态
- #形态/word_pl aftermaths
