---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈæsɪd/； 美：/ˈæsɪd/
- #词性/adj  酸的；酸性的；尖刻的；尖酸的
- #词性/n  酸
# 例句
- The concentration of acid in vomitus or aspirate need not reach this limit .
	- 呕吐物或吸引液内酸的浓度不需要达到这一程度。
- Neutralization is the interaction of a base and an acid .
	- 中和作用是碱和酸的相互作用
- It is treated with acid before being analysed .
	- 对它先用酸处理再进行分析。
# 形态
- #形态/word_pl acids
