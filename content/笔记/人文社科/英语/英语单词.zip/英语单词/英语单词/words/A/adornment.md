---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈdɔːnmənt/； 美：/əˈdɔːrnmənt/
- #词性/n  装饰；装扮；装饰物
# 例句
- The home environment is the place that our mankind relies for existence , the adornment thing in the furniture environment shares good and bad luck with our mankind , and decorating the thing beautifies the composition fraction of the environment indispensability of mankind .
	- 家居环境是我们人类赖以生存的场所，家具环境中的装饰物与我们人类休戚相关，装饰物是美化人类环境不可缺少的组成部分。
- Have adornment , the building adorns the product of material .
	- 有装饰，就有建筑装饰材料的制品。
- A plain necklace was her only adornment .
	- 她身上的饰物就只有一串简单的项链。
# 形态
- #形态/word_pl adornments
