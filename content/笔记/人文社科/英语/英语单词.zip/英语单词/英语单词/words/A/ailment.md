---
tags:
  - 首字母/A
  - 级别/六级
  - 级别/雅思
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈeɪlmənt/； 美：/ˈeɪlmənt/
- #词性/n  小病；小恙；轻病
# 例句
- He has got very good treatment for the ailment , and definitely he 's in good condition .
	- 他的小病得到了很好的治疗，毫无疑问他很健康。
- It 's not just an ailment . It 's something far more serious .
	- 那还不是小病小恙，而是很严重的某种疾病。
- With minor ailments the best thing is often to let nature take its course .
	- 对于小病，往往最好是听其自然。
# 形态
- #形态/word_pl ailments
