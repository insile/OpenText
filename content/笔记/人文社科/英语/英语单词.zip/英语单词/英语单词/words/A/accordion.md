---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkɔːdiən/； 美：/əˈkɔːrdiən/
- #词性/n  手风琴
- #词性/adj  (如手风琴般)可折叠的
# 例句
- The background music was provided by an accordion player .
	- 背景音乐是由一位手风琴乐手演奏的。
- Where some people learned to play the accordion for dances in their community , others took music lessons
	- 一些人学习弹手风琴，为他们社区里的舞蹈表演进行伴奏，而其他人则上音乐课。
- She likes to play the accordion .
	- 她欢喜拉手风琴。
# 形态
- #形态/word_pl accordions
