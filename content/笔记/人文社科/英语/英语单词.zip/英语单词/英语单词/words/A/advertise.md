---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈædvətaɪz/； 美：/ˈædvərtaɪz/
- #词性/v  展现，宣传(自己的事)；(为…)做广告；(在报纸、公共场所公告牌、互联网等上)公布，征聘；登广告
# 例句
- The Government will allow them to advertise on radio and television
	- 政府将准许他们在广播和电视上做广告。
- Religious groups are currently not allowed to advertise on television .
	- 目前禁止宗教团体在电视上做广告。
- We need a new angle for our next advertising campaign .
	- 我们需要从一个新的角度去展开下一次广告活动。
# 形态
- #形态/word_third advertises
- #形态/word_ing advertising
- #形态/word_done advertised
- #形态/word_past advertised
