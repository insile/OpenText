---
tags:
  - 首字母/A
  - 级别/托福
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/əˈkwɪt/； 美：/əˈkwɪt/
- #词性/vt  无罪释放；宣判…无罪；表现好(或坏等)
# 例句
- It turned out they voted to acquit right away , then stayed in the jury room more than an hour longer just to make it look right .
	- 其实是，陪审团的成员们立刻就投了票，要将他无罪释放，但为了做做样子，只好在议事室里呆了一个多小时。
- And you will have no choice but to acquit .
	- 你们就不得不宣判无罪释放。
- He acquitted himself brilliantly in the exams .
	- 他在考试中表现出色。
# 形态
- #形态/word_third acquits
- #形态/word_ing acquitting
- #形态/word_done acquitted
- #形态/word_past acquitted
