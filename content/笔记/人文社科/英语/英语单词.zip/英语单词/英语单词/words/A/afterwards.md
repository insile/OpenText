---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/ˈɑːftəwədz/； 美：/ˈæftərwərdz/
- #词性/adv  之后；后来；以后
# 例句
- Shortly afterwards he met her again .
	- 不久之后，他又遇到了她。
- You can go home afterwards and watch Inspector Morse in colour .
	- 之后你就可以回家，看彩色版的电视连续剧《摩斯警长》。
- Let 's go out now and eat afterwards .
	- 咱们现在出去，然后再吃饭。
