---
tags:
  - 首字母/A
  - 级别/考研
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- 英：/ˈæbdəmən/； 美：/ˈæbdəmən/
- #词性/n  (昆虫的)腹部；腹(部)
# 例句
- Analysis of Closed Injury of Abdomen 63 Cases Caused by Train
	- 火车致闭合性腹外伤63例分析
- Method Apply abdomen needle therapy , which is compared to other methods .
	- [方法]采用腹针方法并与其它方法作对照。
- He was suffering from pains in his abdomen .
	- 他感到腹部剧痛。
# 形态
- #形态/word_pl abdomens
