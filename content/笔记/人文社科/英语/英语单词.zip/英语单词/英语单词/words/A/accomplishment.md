---
tags:
  - 首字母/A
  - 级别/高考四级
掌握: false
模糊: false
---
# 词义
- 英：/əˈkʌmplɪʃmənt/； 美：/əˈkɑːmplɪʃmənt/
- #词性/n  完成；成就；成绩；技艺；才艺；专长
# 例句
- I defy you to come up with one major accomplishment of the current Prime Minister
	- 我敢说你讲不出现任首相的哪怕一项重大成就。
- For a novelist , that 's quite an accomplishment
	- 对于一位小说家来说，那是相当了不起的成就。
- His function is vital to the accomplishment of the agency 's mission .
	- 要完成该机构的使命，他的作用至关重要。
# 形态
- #形态/word_pl accomplishments
