---
tags:
  - 首字母/A
  - 级别/GRE
掌握: false
模糊: false
---
# 词义
- #词性/n  绝望；懒惰，倦怠；漠然，麻痹
# 例句
- Occupation acedia is a very important factor of mental sub-health of teachers in primary and middle schools
	- 职业倦怠与中小学教师心理亚健康
